import { create } from 'zustand';
import {
  fetchSearchResults,
  scrapeHitUrl,
  // fetchEuropeanaRecord, // voorlopig niet nodig
} from '../services/api.service';
import { SearchResult, Hit } from '../types/search-result.interface';
import { QueryState, FiltersState } from '../types/query.interface';

export const initialFilters: FiltersState = {
  types: ['TEXT'],
  providers: ['Europeana', 'Kleio', 'Cito'],
  periods: [],
  noCartoons: false,
  tv: [],
  ka: [],
};

export const useQueryStore = create<QueryState>((set, get) => ({
  terms: ['', '', ''],
  mode: 'ALL',
  aiBoost: false,
  doelgroep: 'Bovenbouw VWO',
  filters: initialFilters,
  hits: [],
  totalHits: 0,
  loading: false,
  error: null,
  selectedHit: null,
  isDetailLoading: false,

  setTerms: (index, value) => {
    set((state) => {
      const newTerms = [...state.terms];
      newTerms[index] = value;
      return { terms: newTerms };
    });
  },

  setFilters: (newFilters) => {
    set((state) => ({
      filters: { ...state.filters, ...newFilters },
    }));
  },

  toggleArrayFilter: (key, value) => {
    set((state) => {
      const currentValues = Array.isArray((state.filters as any)[key])
        ? ((state.filters as any)[key] as (string | number)[])
        : [];

      const exists = currentValues.includes(value);
      const newValues = exists
        ? currentValues.filter((v) => v !== value)
        : [...currentValues, value];

      return {
        filters: {
          ...state.filters,
          [key]: newValues,
        } as FiltersState,
      };
    });
  },

  setSelectedHit: async (hit: Hit | null) => {
    if (!hit) {
      set({ selectedHit: null, isDetailLoading: false });
      return;
    }

    set({ selectedHit: hit, isDetailLoading: true });

    try {
      if (hit.provider === 'Cito') {
        // Cito: volledige tekst zit al in highlight
        set((state) => ({
          selectedHit: state.selectedHit
            ? {
                ...state.selectedHit,
                fullText: state.selectedHit.highlight,
              }
            : null,
          isDetailLoading: false,
        }));
      } else if (hit.provider === 'Kleio') {
        // Kleio: scraper roept backend /scrape aan
        const fullText = await scrapeHitUrl(hit.url);
        set((state) => ({
          selectedHit: state.selectedHit
            ? { ...state.selectedHit, fullText }
            : null,
          isDetailLoading: false,
        }));
      } else {
        // >>> Europeana & andere providers (OpenUp!, Forum Hungaricum, ...)
        // Geen extra Europeana-record call meer: gebruik gewoon de hit zelf.
        const anyHit: any = hit;

        const imageUrl =
          anyHit.thumbnail ||
          (Array.isArray(anyHit.edmPreview) ? anyHit.edmPreview[0] : null) ||
          null;

        const description =
          anyHit.description ||
          (Array.isArray(anyHit.dcDescription)
            ? anyHit.dcDescription[0]
            : null) ||
          hit.title;

        set((state) => ({
          selectedHit: state.selectedHit
            ? {
                ...state.selectedHit,
                fullText: description,
                thumbnail: imageUrl,
              }
            : null,
          isDetailLoading: false,
        }));
      }
    } catch (error) {
      const errorMsg =
        error instanceof Error ? error.message : 'Ophalen mislukt';
      console.error(`Fout bij ophalen details voor ${hit.provider}:`, error);
      set((state) => ({
        selectedHit: state.selectedHit
          ? {
              ...state.selectedHit,
              fullText: `Fout bij ophalen data: ${errorMsg}`,
            }
          : null,
        isDetailLoading: false,
      }));
    }
  },

  executeSearch: async () => {
    const state = get();
    if (state.loading) return;

    set({
      loading: true,
      error: null,
      hits: [],
      totalHits: 0,
      selectedHit: null,
      isDetailLoading: false,
    });

    try {
      const payload = {
        query: state.terms.filter((t) => t.trim() !== ''),
        mode: state.mode,
        aiBoost: state.aiBoost,
        filters: state.filters,
        doelgroep: state.doelgroep,
      };

      const result: SearchResult = await fetchSearchResults(payload);

      set({
        loading: false,
        hits: result.items || [],
        totalHits: result.totalResults || 0,
      });
    } catch (err) {
      const errorMsg =
        err instanceof Error
          ? err.message
          : 'Er is een onbekende fout opgetreden.';
      console.error('Fout bij executeSearch:', err);
      set({
        loading: false,
        error: errorMsg,
        hits: [],
        totalHits: 0,
      });
    }
  },
}));
