const { searchEuropeana } = require('./a11.europeana.cjs');

const cleanLabel = (label) => label.replace(/\[|\]/g, '').trim();

async function suggestChips({ query = "", filters = [] } = {}) {
  if (!query) {
    return { chips: [] };
  }

  console.log(`[REAL B04] Start: Echte Europeana facet-zoekopdracht voor: "${query}"`);
  
  try {
    const params = {
      query: query,
      rows: 0, 
      facet: 'proxy_dc_subject.nl', 
      f_proxy_dc_subject_nl_limit: 15,
    };

    const europeanaData = await searchEuropeana(params);
    
    const subjectFacet = europeanaData.facets?.find(f => f.name === 'proxy_dc_subject.nl');
    
    let chips = [];
    if (subjectFacet && subjectFacet.fields) {
      chips = subjectFacet.fields.map(field => ({
        term: cleanLabel(field.label),
        count: field.count
      }));
    } else {
      chips = [];
    }

    console.log(`[REAL B04] Succes: ${chips.length} chips (als objecten) gevonden.`);
    
    return { chips };

  } catch (error) {
    console.error(`[REAL B04] FOUT bij ophalen Europeana facets:`, error.message);
    throw new Error('Kon Europeana-chips niet ophalen'); 
  }
}

module.exports = { suggestChips };
