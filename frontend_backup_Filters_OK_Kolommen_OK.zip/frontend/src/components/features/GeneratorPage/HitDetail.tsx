import React from 'react';

// We moeten het 'Hit' type hier (helaas) opnieuw definiëren
// Tenzij we het uit src/types importeren, maar laten we het simpel houden
export type Hit = {
  id: string;
  provider: string;
  title: string;
  description?: string;
  url?: string;
  thumbnail?: string | null;
  highlight?: string;
};

interface HitDetailProps {
  hit: Hit | null;
}

const HitDetail: React.FC<HitDetailProps> = ({ hit }) => {
  if (!hit) {
    return (
      <div className="h-full w-full flex items-center justify-center text-sm text-gray-500 p-4 text-center">
        Klik op een titel in de middelste kolom om hier de details te bekijken.
      </div>
    );
  }

  return (
    <div className="h-full w-full overflow-y-auto p-4 space-y-4">
      <header>
        <p className="text-xs uppercase tracking-wide text-gray-400">
          {hit.provider || 'Onbekende provider'}
        </p>
        <h2 className="text-lg font-semibold mt-1">{hit.title || 'Zonder titel'}</h2>
      </header>

      {hit.thumbnail && (
        <div className="w-full">
          <img
            src={hit.thumbnail}
            alt={hit.title || 'thumbnail'}
            className="max-h-64 w-auto rounded-md"
          />
        </div>
      )}

      {hit.description && (
        <p className="text-sm leading-relaxed whitespace-pre-line">
          {hit.description}
        </p>
      )}

      {hit.highlight && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 text-xs whitespace-pre-line">
          <strong>Fragment:</strong>
          <br />
          {hit.highlight}
        </div>
      )}

      {hit.url && (
        <a
          href={hit.url}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center text-sm font-medium text-blue-600 hover:underline"
        >
          Bekijk volledige bron
        </a>
      )}
    </div>
  );
};

export default HitDetail;
