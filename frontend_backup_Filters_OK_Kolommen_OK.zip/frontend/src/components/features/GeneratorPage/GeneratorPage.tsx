import React from 'react';

// Importeer de store (met het juiste pad)
import { useQueryStore } from '../../../state/query.store';

// Importeer de bestaande componenten uit deze map
import { HitList } from './HitList';
import { SearchBar } from './SearchBar';
import { Filters } from './Filters';
import { SearchActions } from './SearchActions';

// Importeer de nieuwe detail component (met 'default' import)
import HitDetail from './HitDetail';

// Importeer het 'Hit' type
import { Hit } from '../../../types/search-result.interface';

export const GeneratorPage: React.FC = () => {
  // **** DE VEILIGE SELECTORS ****
  // We halen hits en selectedHit uit de store.
  // hits kan in eerste instantie undefined zijn → dan maken we er een lege array van.
  const hitsFromStore = useQueryStore((state) => state.hits);
  const selectedHitFromStore = useQueryStore((state) => state.selectedHit);
  // **** EINDE FIX ****

  const hits: Hit[] = (hitsFromStore || []) as Hit[];
  const detailHit = (selectedHitFromStore as Hit) || null;
  const hitCount = hits.length;

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-50">
      {/* Header */}
      <header className="px-4 py-3 border-b border-slate-200 bg-white flex items-center justify-between">
        <h1 className="text-base font-semibold">
          Kleio – bronzoeker &amp; lesgenerator
        </h1>
      </header>

      {/* Main 3-koloms layout */}
      {/* 'overflow-hidden' is belangrijk om dubbele scrollbars te voorkomen */}
      <main className="flex-1 px-4 py-3 overflow-hidden">
        <div className="grid grid-cols-[minmax(260px,0.9fr)_minmax(320px,1.1fr)_minmax(320px,1.1fr)] gap-4 h-full">

          {/* Kolom 1: filters / zoekvelden (met JOUW componenten) */}
          <section className="bg-white border border-slate-200 rounded-xl p-3 flex flex-col overflow-y-auto">
            <div className="space-y-6">
              <div>
                <h2 className="text-lg font-semibold text-gray-800 mb-3">
                  Zoektermen
                </h2>
                <SearchBar />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-800 mb-3">
                  Filters
                </h2>
                <Filters />
              </div>
              <div>
                <SearchActions />
              </div>
            </div>
          </section>

          {/* Kolom 2: hitlist */}
          <section className="bg-white border border-slate-200 rounded-xl p-3 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-semibold">Gevonden bronnen</h2>
              <p className="text-xs text-gray-500">
                {hitCount} resultaat{hitCount === 1 ? '' : 'en'}
              </p>
            </div>
            <div className="flex-1 overflow-y-auto">
              <HitList />
            </div>
          </section>

          {/* Kolom 3: detail van geselecteerde bron */}
          <section className="bg-white border border-slate-200 rounded-xl flex flex-col">
            <HitDetail hit={detailHit} />
          </section>
        </div>
      </main>
    </div>
  );
};

// Voor het geval je GeneratorPage als default importeert
export default GeneratorPage;

