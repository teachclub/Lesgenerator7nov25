import { create } from 'zustand';
import { fetchSearchResults } from '../services/api.service';
import { SearchResult, Hit } from '../types/search-result.interface';
import { QueryState, FiltersState } from '../types/query.interface';

export const initialFilters: FiltersState = {
  types: ['TEXT'],
  providers: ['Europeana', 'Kleio', 'Cito'], 
  periods: [],
  noCartoons: false,
  tv: [],
  ka: [],
};

export const useQueryStore = create<QueryState>((set, get) => ({
  terms: ['', '', ''],
  mode: 'ALL',
  aiBoost: false,
  doelgroep: 'Bovenbouw VWO',
  filters: initialFilters,
  hits: [],
  totalHits: 0,
  loading: false,
  error: null,
  selectedHit: null,

  setTerms: (index, value) => {
    set((state) => {
      const newTerms = [...state.terms];
      newTerms[index] = value;
      return { terms: newTerms };
    });
  },

  setFilters: (newFilters) => {
    set((state) => ({
      filters: { ...state.filters, ...newFilters },
    }));
  },

  toggleArrayFilter: (key, value) => {
    set((state) => {
      const filterKey = key as 'providers' | 'tv' | 'ka';
      const currentValues = state.filters[filterKey] as (string | number)[];

      const newValues = currentValues.includes(value)
        ? currentValues.filter((v) => v !== value)
        : [...currentValues, value];

      return {
        filters: {
          ...state.filters,
          [key]: newValues,
        },
      };
    });
  },

  setSelectedHit: (hit: Hit | null) => {
    // **** DIT IS DE DEBUG-REGEL ****
    console.log('KLIK GEDETECTEERD! Geselecteerde hit:', hit?.id || 'null');
    // **** EINDE DEBUG ****
    set({ selectedHit: hit });
  },

  executeSearch: async () => {
    const state = get();
    if (state.loading) return;
    set({ loading: true, error: null, hits: [], totalHits: 0, selectedHit: null });
    try {
      const payload = {
        query: state.terms.filter(t => t.trim() !== ''),
        mode: state.mode,
        aiBoost: state.aiBoost,
        filters: state.filters,
        doelgroep: state.doelgroep,
      };
      const result: SearchResult = await fetchSearchResults(payload);
      set({
        loading: false,
        hits: result.items || [],
        totalHits: result.totalResults || 0,
      });
    } catch (err) {
      const errorMsg = (err instanceof Error) ? err.message : 'Er is een onbekende fout opgetreden.';
      console.error('Fout bij executeSearch:', err);
      set({ loading: false, error: errorMsg, hits: [], totalHits: 0 });
    }
  },
}));
