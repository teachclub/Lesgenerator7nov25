import { Hit } from './search-result.interface';

export interface FiltersState {
  types: string[];
  providers: string[];
  periods: string[];
  noCartoons: boolean;
  tv: string[]; // Terug naar de simpele string-array
  ka: number[];
}

export interface QueryState {
  // Oude state
  terms: string[];
  mode: 'ALL' | 'ANY';
  aiBoost: boolean;
  doelgroep: string;
  filters: FiltersState;
  hits: Hit[];
  totalHits: number;
  loading: boolean;
  error: string | null;

  // **** NIEUWE STATE TYPES ****
  selectedHit: Hit | null;
  // **** EINDE NIEUW ****

  // Oude functies
  setTerms: (index: number, value: string) => void;
  setFilters: (newFilters: Partial<FiltersState>) => void;
  toggleArrayFilter: (key: 'providers' | 'tv' | 'ka', value: string | number) => void;
  executeSearch: () => Promise<void>;

  // **** NIEUWE FUNCTIE TYPE ****
  setSelectedHit: (hit: Hit | null) => void;
  // **** EINDE NIEUW ****
}
