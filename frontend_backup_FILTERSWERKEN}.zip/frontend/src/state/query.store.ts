import { create } from 'zustand';
import { fetchSearchResults } from '../services/api.service';
import { SearchResult } from '../types/search-result.interface';
import { QueryState, FiltersState } from '../types/query.interface';

export const initialFilters: FiltersState = {
  types: ['TEXT'],
  // ZORG DAT CITO HIER STANDAARD AAN STAAT
  providers: ['Europeana', 'Kleio', 'Cito'], 
  periods: [],
  noCartoons: false,
  tv: [],
  ka: [],
};

export const useQueryStore = create<QueryState>((set, get) => ({
  terms: ['', '', ''],
  mode: 'ALL',
  aiBoost: false,
  doelgroep: 'Bovenbouw VWO',
  filters: initialFilters,

  hits: [],
  totalHits: 0,
  loading: false,
  error: null,

  setTerms: (index, value) => {
    set((state) => {
      const newTerms = [...state.terms];
      newTerms[index] = value;
      return { terms: newTerms };
    });
  },

  setFilters: (newFilters) => {
    set((state) => ({
      filters: { ...state.filters, ...newFilters },
    }));
  },

  // Functie om specifiek array-filters (zoals providers) te togglen
  toggleArrayFilter: (key, value) => {
    set((state) => {
      const currentValues = state.filters[key] as string[];
      const newValues = currentValues.includes(value)
        ? currentValues.filter((v) => v !== value) // Verwijder
        : [...currentValues, value]; // Voeg toe

      return {
        filters: {
          ...state.filters,
          [key]: newValues,
        },
      };
    });
  },

  executeSearch: async () => {
    const state = get();
    if (state.loading) return;

    set({ loading: true, error: null, hits: [], totalHits: 0 });

    try {
      // Bouw de payload op basis van de huidige state
      const payload = {
        query: state.terms.filter(t => t.trim() !== ''), // Alleen niet-lege termen
        mode: state.mode,
        aiBoost: state.aiBoost,
        filters: state.filters,
        doelgroep: state.doelgroep,
      };

      const result: SearchResult = await fetchSearchResults(payload);

      set({
        loading: false,
        hits: result.items || [],
        totalHits: result.totalResults || 0,
      });

    } catch (err) {
      const errorMsg = (err instanceof Error) ? err.message : 'Er is een onbekende fout opgetreden.';
      console.error('Fout bij executeSearch:', err);
      set({ loading: false, error: errorMsg, hits: [], totalHits: 0 });
    }
  },
}));
