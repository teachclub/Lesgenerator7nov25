import { create } from "zustand";

export type Source = { id: string; title: string; url?: string; type?: string };

type SelState = {
  selected: Source[];
  toggle: (src: Source) => void;
  remove: (id: string) => void;
  clear: () => void;
};

export const useSelectionStore = create<SelState>((set, get) => ({
  selected: [],
  toggle: (src) => {
    const cur = get().selected;
    const exists = cur.some((s) => s.id === src.id);
    if (exists) set({ selected: cur.filter((s) => s.id !== src.id) });
    else if (cur.length < 12) set({ selected: [...cur, src] });
  },
  remove: (id) => set((s) => ({ selected: s.selected.filter((x) => x.id !== id) })),
  clear: () => set({ selected: [] }),
}));
