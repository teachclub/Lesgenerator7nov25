import { Hit } from './search-result.interface';

export interface FiltersState {
  types: string[];
  providers: string[];
  periods: string[];
  noCartoons: boolean;
  tv: string[]; // Tijdvakken
  ka: number[]; // Kenmerkende Aspecten
}

export interface QueryState {
  terms: string[];
  mode: 'ALL' | 'ANY';
  aiBoost: boolean;
  doelgroep: string;
  filters: FiltersState;

  hits: Hit[];
  totalHits: number;
  loading: boolean;
  error: string | null;

  setTerms: (index: number, value: string) => void;
  setFilters: (newFilters: Partial<FiltersState>) => void;
  toggleArrayFilter: (key: keyof FiltersState, value: string | number) => void;
  executeSearch: () => Promise<void>;
}
