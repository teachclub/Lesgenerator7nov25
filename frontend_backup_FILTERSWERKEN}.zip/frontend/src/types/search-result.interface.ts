export interface Hit {
  id: string;
  provider: string;
  title: string;
  description: string;
  url: string;
  thumbnail?: string;
  score: number;
  highlight?: string; // HTML-string met highlights
}

export interface SearchResult {
  totalResults: number;
  items: Hit[];
}
