import React from 'react';
import { useQueryStore } from '../../../state/query.store';
import { useShallow } from 'zustand/react/shallow';
import { ClipLoader } from 'react-spinners';
import { Hit } from '../../../types/search-result.interface';

// Dit is de sub-component voor één zoekresultaat
const HitItem: React.FC<{ hit: Hit }> = ({ hit }) => {
  // Helper om de 'highlight' (vetgedrukte zoekresultaten)
  // veilig als HTML weer te geven.
  const createMarkup = (htmlContent: string | undefined) => {
    return { __html: htmlContent || hit.description || '' };
  };

  return (
    <div className="border border-gray-200 rounded-lg p-4 mb-4 shadow-sm hover:shadow-md transition-shadow duration-200 bg-white">
      <a 
        href={hit.url} 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-lg font-semibold text-blue-700 hover:underline mb-1"
      >
        {hit.title}
      </a>
      <p className="text-xs text-gray-500 mb-2">
        Bron: {hit.provider} (ID: {hit.id})
      </p>
      <p 
        className="text-sm text-gray-700 mb-2 snippet"
        dangerouslySetInnerHTML={createMarkup(hit.highlight)}
      />
    </div>
  );
};


// Dit is de hoofdcomponent die de lijst beheert
export const HitList: React.FC = () => {
  // GEBRUIK 'loading', NIET 'isLoading'
  const { hits, loading, error, totalHits } = useQueryStore(
    useShallow((s) => ({
      hits: s.hits,
      loading: s.loading,
      error: s.error,
      totalHits: s.totalHits,
    }))
  );

  // 1. Loading state (Spinner)
  if (loading) {
    return (
      <div className="flex justify-center items-center h-40">
        <ClipLoader color="#4A90E2" size={50} />
      </div>
    );
  }

  // 2. Error state
  if (error) {
    return (
      <div className="border-l-4 border-red-500 bg-red-50 p-4 rounded-md">
        <p className="font-bold text-red-800">Er is een fout opgetreden</p>
        <p className="text-red-700">{error}</p>
      </div>
    );
  }

  // 3. Geen hits (na een succesvolle, lege zoekopdracht)
  if (!hits || hits.length === 0) {
    return (
      <div className="text-center text-gray-500 italic p-4">
        Geen resultaten gevonden. Pas je zoektermen of filters aan.
      </div>
    );
  }

  // 4. We hebben hits!
  return (
    <div className="mt-6 md:mt-0">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Resultaten ({totalHits})
      </h2>
      <div>
        {hits.map((hit) => (
          <HitItem key={hit.id} hit={hit} />
        ))}
      </div>
    </div>
  );
};
