import React from 'react';
import { useQueryStore } from '../../../state/query.store';
import { useShallow } from 'zustand/react/shallow';

// ZORG DAT DEZE LIJST SYNCHROON IS MET DE STORE
const AVAILABLE_PROVIDERS = ['Europeana', 'Kleio', 'Cito'];

export const Filters: React.FC = () => {
  const { providers, toggleArrayFilter } = useQueryStore(
    useShallow((s) => ({
      providers: s.filters.providers,
      toggleArrayFilter: s.toggleArrayFilter,
    }))
  );

  const handleProviderChange = (provider: string) => {
    toggleArrayFilter('providers', provider);
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-gray-700 mb-2">
          Selecteer Bronnen (Providers)
        </h3>
        <div className="space-y-1">
          {AVAILABLE_PROVIDERS.map((provider) => (
            <label key={provider} className="flex items-center">
              <input
                type="checkbox"
                className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                checked={providers.includes(provider)}
                onChange={() => handleProviderChange(provider)}
              />
              <span className="ml-2 text-sm text-gray-800">{provider}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Hier komen later de andere filters, zoals Tijdvak en KA */}

    </div>
  );
};
