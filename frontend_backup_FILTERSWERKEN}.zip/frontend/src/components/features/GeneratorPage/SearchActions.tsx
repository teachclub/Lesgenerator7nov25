import React from 'react';
import { useQueryStore } from '../../../state/query.store';
import { useShallow } from 'zustand/react/shallow';

export const SearchActions: React.FC = () => {
  // GEBRUIK 'loading', NIET 'isLoading'
  const { loading, executeSearch } = useQueryStore(
    useShallow((s) => ({
      loading: s.loading, 
      executeSearch: s.executeSearch,
    }))
  );

  const handleSearch = () => {
    if (loading) return;
    executeSearch();
  };

  return (
    <button
      onClick={handleSearch}
      disabled={loading}
      className={`w-full px-4 py-2 rounded-md font-semibold text-white transition-colors duration-200
        ${loading 
          ? 'bg-gray-400 cursor-not-allowed' 
          : 'bg-blue-600 hover:bg-blue-700'
        }`}
    >
      {loading ? 'Bezig met zoeken...' : 'Zoek bronnen'}
    </button>
  );
};
