import React from 'react';
import { SearchBar } from './SearchBar';
import { HitList } from './HitList';
import { SearchActions } from './SearchActions';
import { Filters } from './Filters'; // <-- NIEUW

export const GeneratorPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">

        {/* Linker kolom */}
        <div className="md:col-span-1">
          <div className="sticky top-8 space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-800 mb-3">
                Zoektermen
              </h2>
              <SearchBar />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-800 mb-3">
                Bronnen
              </h2>
              <Filters />
            </div>
            <div>
              <SearchActions />
            </div>
          </div>
        </div>

        {/* Rechter kolom */}
        <div className="md:col-span-2">
          <HitList />
        </div>

      </div>
    </div>
  );
};
