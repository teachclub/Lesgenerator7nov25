import React from 'react';
import { useQueryStore } from '../../../state/query.store';
import { useShallow } from 'zustand/react/shallow';

export const SearchBar: React.FC = () => {
  const { terms, setTerms } = useQueryStore(
    useShallow((s) => ({
      terms: s.terms,
      setTerms: s.setTerms,
    }))
  );

  const handleChange = (index: number, value: string) => {
    setTerms(index, value);
  };

  return (
    <div className="space-y-4">
      <div>
        <label 
          htmlFor="term-0" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Zoekterm 1
        </label>
        <input
          id="term-0"
          type="text"
          className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
          placeholder="Typ hier je zoekterm"
          value={terms[0] || ''}
          onChange={(e) => handleChange(0, e.target.value)}
        />
      </div>

      <div>
        <label 
          htmlFor="term-1" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Zoekterm 2 (Optioneel)
        </label>
        <input
          id="term-1"
          type="text"
          className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
          placeholder="Optioneel"
          value={terms[1] || ''}
          onChange={(e) => handleChange(1, e.target.value)}
        />
      </div>

      <div>
        <label 
          htmlFor="term-2" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Zoekterm 3 (Optioneel)
        </label>
        <input
          id="term-2"
          type="text"
          className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
          placeholder="Optioneel"
          value={terms[2] || ''}
          onChange={(e) => handleChange(2, e.target.value)}
        />
      </div>
    </div>
  );
};
