import React from "react";
import { GeneratorPage } from "./components/features/GeneratorPage/GeneratorPage";

const App: React.FC = () => <GeneratorPage />;

export default App;
