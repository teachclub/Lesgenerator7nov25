export { fetchChips } from "./useChipsApi";

