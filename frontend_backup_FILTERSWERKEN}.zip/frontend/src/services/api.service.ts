// De URL van je Express backend
const API_BASE_URL = 'http://localhost:8080/api';

export const fetchSearchResults = async (payload: any) => {
  const response = await fetch(`${API_BASE_URL}/search`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    // Probeer een meer specifieke foutmelding van de backend te krijgen
    let errorMsg = `HTTP error! Status: ${response.status}`;
    try {
      const errorData = await response.json();
      errorMsg = errorData.message || errorData.error || errorMsg;
    } catch (e) {
      // Geen JSON-body, gebruik de standaard status
    }
    throw new Error(errorMsg);
  }

  return response.json();
};
