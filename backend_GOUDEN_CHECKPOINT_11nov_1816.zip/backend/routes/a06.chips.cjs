const express = require('express');
const router = express.Router();
const { suggestChips } = require('../services/a06.chips.cjs');

router.post('/chips', async (req, res) => {
  try {
    const { query = "", filters = [] } = req.body || {};
    
    if (!query) {
      console.warn("[B04] /api/chips 400: query is verplicht");
      return res.status(400).json({ ok: false, error: "query is verplicht" });
    }

    console.log("[B04] /api/chips", { query, filters });
    
    const data = await suggestChips({ query, filters });

    res.status(200).json({
      ok: true,
      chips: Array.isArray(data?.chips) ? data.chips : [],
      meta: { count: (data?.chips || []).length },
    });
  } catch (err) {
    console.error("[B04] /api/chips ERROR:", err.message);
    res.status(500).json({ ok: false, chips: [], error: err.message || 'Interne server fout' });
  }
});

module.exports = router;
