const express = require('express');
const router = express.Router();
const { generateProposals } = require('../services/a25.proposals.cjs');

router.post('/pre-selection', async (req, res) => {
  try {
    const { query = "", filters = [], doelgroep } = req.body || {};
    
    if (!query) {
      console.warn("[B01] /api/pre-selection 400: query is verplicht");
      return res.status(400).json({ ok: false, error: "query is verplicht" });
    }

    console.log("[B01] /api/pre-selection", { query, filters, doelgroep });
    
    const data = await generateProposals({ query, filters, doelgroep });

    res.status(200).json({
      ok: true,
      proposals: data.proposals || [],
    });
  } catch (err) {
    console.error("[B01] /api/pre-selection ERROR:", err.message);
    res.status(500).json({ ok: false, proposals: [], error: err.message || 'Interne server fout' });
  }
});

module.exports = router;
