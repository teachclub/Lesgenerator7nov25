async function generateProposals({ query, filters, doelgroep }) {
  console.log(`[MOCK B01] Start: Lesvoorstellen genereren voor: "${query}"`);
  
  await new Promise(resolve => setTimeout(resolve, 1500));

  const mockProposals = [
    {
      id: "prop1",
      title: "Voorstel 1: De Impact van Luther",
      description: "Een les over de directe gevolgen van de Reformatie.",
      hoofdvraag: "Wat was de *directe* impact van Luthers 95 stellingen op de kerk?",
      presentisme: "Vergelijk met moderne 'cancel culture'.",
      lesopbrengst: "Leerlingen begrijpen de rol van media (drukpers) in protest."
    },
    {
      id: "prop2",
      title: "Voorstel 2: Calvijn vs. Luther",
      description: "Een vergelijkende les over de twee hervormers.",
      hoofdvraag: "Waarin verschilde Calvijns visie op predestinatie van die van Luther?",
      presentisme: "Hoe kijken we nu aan tegen 'voorbestemming' (determinisme)?",
      lesopbrengst: "Leerlingen kunnen de belangrijkste theologische verschillen benoemen."
    },
    {
      id: "prop3",
      title: "Voorstel 3: De Politieke Gevolgen",
      description: "Focus op de opstand en de rol van Duitse vorsten.",
      hoofdvraag: "Waarom steunden zoveel Duitse vorsten Luther, los van religie?",
      presentisme: "Vergelijk met politieke allianties van vandaag.",
      lesopbrengst: "Leerlingen zien de mix van religie en politiek in de Reformatie."
    }
  ];

  console.log("[MOCK B01] Succes: 3 mock-voorstellen gegenereerd.");
  
  return { proposals: mockProposals };
}

module.exports = { generateProposals };
