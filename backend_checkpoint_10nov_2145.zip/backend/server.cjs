const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/', (req, res) => {
  res.json({ ok: true, service: 'masterprompt-backend', ts: new Date().toISOString() });
});

app.post('/api/chips', (req, res) => {
  const { query } = req.body || {};
  res.json({
    groups: [
      { category: 'Personen', items: [{ label: 'Maarten Luther', count: 574 }, { label: 'Erasmus', count: 11200 }] },
      { category: 'Concepten', items: [{ label: 'Reformatie', count: 462 }, { label: 'Aflaat', count: 443 }] },
      { category: 'Plaatsen', items: [{ label: 'Wittenberg', count: 104 }, { label: 'Worms', count: 10198 }] }
    ],
    echo: { query }
  });
});

app.post('/api/pre-selection', (req, res) => {
  const { query, filters } = req.body || {};
  res.json({
    proposals: [
      { id: '1', title: 'De breuk met Rome: oorzaak-gevolg in kaart', rationale: 'Aflaten > kritiek > breuk; leerlingen maken causale ketens.' },
      { id: '2', title: '95 stellingen als “viral”: rol van drukpers', rationale: 'Technologie versnelt ideeënverspreiding; weeg de impact.' },
      { id: '3', title: 'Religie & macht: vorsten, steden en geloof', rationale: 'Waarom kozen machtsblokken verschillende confessies?' }
    ],
    echo: { query, filters }
  });
});

app.post('/api/get-sources-for-proposal', (req, res) => {
  const { proposalId, proposal } = req.body || {};
  const pid = proposalId || (proposal && proposal.id) || '1';
  const presetSources = [
    { id: `preset-${pid}-1`, title: '95 stellingen (selectie, 1517)', url: 'https://example.org/95', type: 'text', preview: 'Kritiek op aflaten…', translation: 'Criticism of indulgences…' }
  ];
  const otherSources = [
    { id: `other-${pid}-1`, title: 'Rijksdag van Worms (1521) – fragment', url: 'https://example.org/worms', type: 'text', preview: 'Herroeping besproken…', translation: 'Recantation discussed…' }
  ];
  res.json({ presetSources, otherSources, echo: { pid } });
});

app.post('/api/generate/lesson', (req, res) => {
  const { proposal, sources } = req.body || {};
  const teacherGuide = [
    'WAT: Leerlingen onderzoeken oorzaken en gevolgen van de Reformatie.',
    'HOE: Werk met geselecteerde bronnen (preset + eigen keuzes), vul oorz./gevolg-tabellen en positioneer in kwadrant.',
    'WAAROM: Historisch redeneren en anti-presentistisch perspectief (Vreemde Verleden).'
  ].join('\n');
  const answerKey = '- Modelantwoorden bij kernvragen (placeholder)\n- Verwachte argumenten per dimensie (politiek/sociaal/economisch/mentaal).';
  const sourcesSheet = (sources || []).map((s, i) => `${i + 1}. [${s.title}](${s.url}) — ${s.type}`).join('\n') || 'Nog geen bronnen geselecteerd.';
  const studentWorksheet = [
    '1) Formuleer de hoofdvraag in leerlingentaal.',
    '2) Vul de oorzaken/gevolgen-tabel per bron.',
    '3) Positioneer oorzaken in het (sub)dimensie-kwadrant en licht toe.',
    '4) Schrijf een beargumenteerde conclusie (anti-presentistisch).'
  ].join('\n');
  const lessonText = 'Volledige les (markdown) met vertaalde snippets per bron. (placeholder)';
  res.json({ lesson: { teacherGuide, answerKey, sourcesSheet, studentWorksheet, lessonText }, echo: { picked: proposal && proposal.title, count: sources ? sources.length : 0 } });
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`masterprompt-backend up on :${PORT}`));

