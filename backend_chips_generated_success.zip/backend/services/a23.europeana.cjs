// services/a23.europeana.cjs
// Europeana v2 Search helper – levert altijd { total, docs, facets } terug.
const BASE_URL = "https://api.europeana.eu/record/v2/search.json";
const WSKEY = process.env.EUROPEANA_WSKEY;

function assertWskey() {
  if (!WSKEY) {
    throw new Error("[a23.europeana] EUROPEANA_WSKEY ontbreekt in env");
  }
}

function arr(x) {
  if (!x) return [];
  return Array.isArray(x) ? x : [x];
}

function norm(s) {
  return String(s || "")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

// --- PATCHED FUNCTION ---
function buildQuery(terms = [], mode = "AND") {
  const t = (Array.isArray(terms) ? terms : [terms])
    .map((s) => String(s || "").trim())
    .filter(Boolean);
  if (t.length === 0) return "*"; // <-- BELANGRIJK: Europeana wil geen lege query
  const op = mode === "OR" ? " OR " : " AND ";
  return t.map((tt) => `"${tt}"`).join(op);
}

function appendFilters(params, filters = {}) {
  if (filters.geenBeeldbronnen) {
    params.append('qf', 'NOT (TYPE:"IMAGE" OR TYPE:"VIDEO")');
  }
  if (filters.geenTekstbronnen) {
    params.append('qf', 'NOT (TYPE:"TEXT")');
  }
  return params;
}

// --- PATCHED FUNCTION ---
function buildParams(payload = {}) {
  const {
    terms = [],
    mode = "AND",
    rows = 24,
    page = 1,
    facets,
    filters = {},
  } = payload;

  const params = new URLSearchParams();

  // ✅ query mag nooit leeg zijn
  const q = buildQuery(terms, mode);
  params.set("query", q);

  // ✅ rows/page veilig normaliseren
  const r = Number.isFinite(Number(rows)) ? Math.max(0, Math.floor(Number(rows))) : 24;
  const p = Number.isFinite(Number(page)) ? Math.max(1, Math.floor(Number(page))) : 1;

  params.set("rows", String(r));

  // ✅ start ALLEEN zetten als rows > 0 (Europeana kan anders zeuren bij facets)
  if (r > 0) {
    const start = (p - 1) * r; // p>=1, r>=0 → nooit negatief
    params.set("start", String(start));
  } // bij r===0 laten we 'start' geheel weg

  params.set("wskey", WSKEY);

  // Profiel: voor rijke docs én facets.
  params.set("profile", "rich");
  params.append('reusability', 'open');
  params.append('media', 'true');

  appendFilters(params, filters);

  // ✅ facets alleen toevoegen als gevraagd
  if (Array.isArray(facets) && facets.length > 0) {
    params.set("facet", "true");
    facets.forEach((f) => params.append("facet.field", String(f)));
    params.append("profile", "facets"); // profile=facets overschrijft 'rich', dat is ok.
  }

  return params;
}


function normaliseDoc(item) {
  const title = arr(item.title)[0] || item.title || item.guid || "Zonder titel";
  const link =
    item.edmIsShownAt ||
    item.guid ||
    (Array.isArray(item.link) ? item.link[0] : item.link) ||
    null;
  const thumbnail =
    (Array.isArray(item.edmPreview) && item.edmPreview[0]) ||
    item.edmPreview ||
    item.edmIsShownBy ||
    null;

  return {
    id: item.id || item.guid || item.link || cryptoRandomId(),
    title: String(title),
    link: link || null,
    thumbnail: thumbnail || null,
    provider: arr(item.provider)[0] || item.provider || null,
    dataProvider: arr(item.dataProvider)[0] || item.dataProvider || null,
    year: arr(item.year)[0] || item.year || null,
    type: arr(item.type)[0] || item.type || item.media || null,

    // handige arrays voor chips-extract
    dcCreator: arr(item.dcCreator || item["dc:creator"]),
    dcSubject: arr(item.dcSubject || item["dc:subject"]),
    dctermsSpatial: arr(
      item.dctermsSpatial ||
        item["dcterms:spatial"] ||
        item.edmPlaceLabel ||
        item.edmPlace ||
        item.spatial ||
        item.place ||
        item.coverage ||
        item["dc:coverage"]
    ),
    dates: arr(
      item["dcterms:created"] ||
        item["dcterms:issued"] ||
        item["dc:date"] ||
        item.date
    ),
    raw: item,
  };
}

function normaliseFacets(data) {
  const out = { who: [], what: [], where: [], YEAR: [] };
  if (Array.isArray(data?.facets)) {
    data.facets.forEach((f) => {
      const field = String(f.field || "").toUpperCase();
      const bucket = Array.isArray(f.fields) ? f.fields : [];
      const mapped = bucket
        .filter((x) => x && (x.label || x.term))
        .map((x) => ({
          term: norm(x.label || x.term),
          count: Number(x.count || x.n || 0) || 0,
        }));
      if (["WHO", "WHAT", "WHERE", "YEAR"].includes(field)) {
        out[field === "WHO" ? "who" : field === "WHAT" ? "what" : field === "WHERE" ? "where" : "YEAR"] = mapped;
      }
    });
    return out;
  }

  const tryField = (key, dest) => {
    const v =
      data?.[key] ||
      data?.facetFields?.[key] ||
      data?.facet_counts?.[key] ||
      data?.facets?.[key];
    if (!v) return;
    if (Array.isArray(v)) {
      if (v.length && typeof v[0] === "object") {
        out[dest] = v
          .filter((x) => x && (x.label || x.term))
          .map((x) => ({
            term: norm(x.label || x.term),
            count: Number(x.count || x.n || 0) || 0,
          }));
      } else {
        const arr = [];
        for (let i = 0; i < v.length; i += 2) {
          if (v[i] != null)
            arr.push({ term: norm(v[i]), count: Number(v[i + 1] || 0) || 0 });
        }
        out[dest] = arr;
      }
    } else if (typeof v === "object") {
      out[dest] = Object.entries(v).map(([k, val]) => ({
        term: norm(k),
        count: Number(val || 0) || 0,
      }));
    }
  };

  tryField("who", "who");
  tryField("WHAT", "what");
  tryField("what", "what");
  tryField("where", "where");
  tryField("WHERE", "where");
  tryField("YEAR", "YEAR");
  tryField("year", "YEAR");

  return out;
}

function cryptoRandomId() {
  return "it_" + Math.random().toString(36).slice(2, 10);
}

async function performEuropeanaSearch(payload = {}) {
  assertWskey();

  const params = buildParams(payload);
  const url = `${BASE_URL}?${params.toString()}`;

  const res = await fetch(url);
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(
      `[a23.europeana] HTTP ${res.status} – ${res.statusText} – ${txt.slice(
        0,
        200
      )}`
    );
  }

  const data = await res.json();

  const items =
    data?.items || data?.results || data?.docs || data?.response?.docs || [];
  const docs = Array.isArray(items) ? items.map(normaliseDoc) : [];

  const total =
    (typeof data?.total === "number" && data.total) ||
    (typeof data?.totalResults === "number" && data.totalResults) ||
    (typeof data?.itemsCount === "number" && data.itemsCount) ||
    (typeof data?.response?.numFound === "number" && data.response.numFound) ||
    docs.length;

  const facets = normaliseFacets(data);

  return { total, docs, facets, raw: data };
}

module.exports = { performEuropeanaSearch };
