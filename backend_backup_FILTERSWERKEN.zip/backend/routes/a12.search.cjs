// routes/a12.search.cjs
// Versie met de "Lege Query Fix" voor Kleio
const express = require("express");
const router = express.Router();
const { searchEuropeana } = require("../services/a11.europeana.cjs");
const { scrapeKleio } = require("../services/a27.kleio.cjs");
const { expandKeywordsWithGemini } = require("../services/a06.chips.cjs");
const { searchCito } = require("../services/a28.cito.cjs");
const kaMap = require("../data/kaMap.cjs");

// --- Helpers (buildEuropeanaQF, Data Transformatie) ---
function buildEuropeanaQF(filters = {}) {
  // ... (code blijft hetzelfde)
  const qf = [];
  const types = Array.isArray(filters.types) && filters.types.length > 0 ? filters.types : ["TEXT"];
  types.forEach((t) => { qf.push(`TYPE:"${t}"`); });
  const periodMap = {
    "16e eeuw": "YEAR:[1500 TO 1599]",
    "17e eeuw": "YEAR:[1600 TO 1699]",
    "18e eeuw": "YEAR:[1700 TO 1799]",
    "19e eeuw": "YEAR:[1800 TO 1899]",
    "20e eeuw": "YEAR:[1900 TO 1999]",
  };
  if (Array.isArray(filters.periods) && filters.periods.length > 0) {
    const periodQueries = filters.periods
      .map((p) => periodMap[p])
      .filter(Boolean);
    if (periodQueries.length > 0) qf.push(periodQueries.join(" OR "));
  }
  return qf;
}

function transformEuropeanaResponse(eu) {
  // ... (code blijft hetzelfde)
  const totalResults = eu.totalResults || 0;
  if (!eu.items || eu.items.length === 0) return { totalResults, items: [] };
  return {
    totalResults,
    items: eu.items.map((item) => ({
      id: item.id, title: item.title?.[0] || "Titel onbekend", provider: "Europeana",
      thumbnail: item.edmPreview?.[0] || null, url: item.guid?.[0] || item.link || null,
    })),
  };
}

function transformKleioResponse(kleioData) {
  // ... (code blijft hetzelfde)
  if (!kleioData || kleioData.length === 0) return [];
  return kleioData.map((item) => ({
    id: item.link, title: item.title || "Titel onbekend", provider: "Kleio",
    thumbnail: null, url: item.link || null, description: item.description || "",
  }));
}

function transformCitoResponse(citoData) {
  // ... (code blijft hetzelfde)
  if (!Array.isArray(citoData) || citoData.length === 0) return [];
  return citoData.map((item, index) => ({
    id: item.id || `cito-${index}`, title: item.title || "Titel onbekend", provider: "Cito",
    thumbnail: item.thumbnail || null, url: item.url || null,
    description: item.description || "", toelichting: item.toelichting || "",
  }));
}

function getKeywordsFromTvKa(filters = {}) {
  // ... (code blijft hetzelfde)
  const { tv = [], ka = [] } = filters;
  const terms = new Set();
  let tvLabel = "";
  const kaLabels = [];
  tv.forEach((tvCode) => {
    const tvDef = kaMap[tvCode];
    if (!tvDef) return;
    tvLabel = tvDef.label || tvCode;
    tvDef.ka.forEach((kaDef) => {
      if (ka.length === 0 || ka.includes(kaDef.id)) {
        kaLabels.push(kaDef.label);
        kaDef.kleioKeywords.forEach((kw) => terms.add(kw));
      }
    });
  });
  return { baseKeywords: Array.from(terms), tvLabel, kaLabels };
}

// --- Route ---
router.post("/search", async (req, res) => {
  try {
    const payload = req.body || {};
    console.log("[/api/search] Ontvangt payload:", payload);

    const queryTerms = Array.isArray(payload.query) ? payload.query.filter(Boolean) : [];
    const mode = payload.mode || "ALL";
    const filters = payload.filters || {};
    const doelgroep = payload.doelgroep || "onbekend";
    const aiBoost = false; // (Staat nog steeds veilig 'uit')

    const providers =
      Array.isArray(filters.providers) && filters.providers.length > 0
        ? filters.providers
        : ["Europeana", "Kleio", "Cito"];

    const useEuropeana = providers.includes("Europeana");
    const useKleio = providers.includes("Kleio");
    const useCito = providers.includes("Cito");

    // 1. Keywords uit tv/ka
    const { baseKeywords } = getKeywordsFromTvKa(filters);

    // 2. Handmatige zoektermen
    let manualQuery = "";
    if (queryTerms.length > 0) {
      manualQuery = mode === "ALL" ? queryTerms.join(" ") : `(${queryTerms.join(" OR ")})`;
    }

    // 3. Combineer met tv/ka-keywords
    let kaQuery = "";
    if (baseKeywords.length > 0) {
      kaQuery = `(${baseKeywords.map((kw) => `"${kw}"`).join(" OR ")})`;
    }
    let queryString = [manualQuery, kaQuery].filter(Boolean).join(" AND ");
    if (filters.noCartoons) {
      queryString = queryString ? `${queryString} NOT (spotprent OR cartoon)` : "NOT (spotprent OR cartoon)";
    }
    if (!queryString || queryString.trim() === "") {
      queryString = "*";
    }

    // Europeana parameters
    const qfParams = buildEuropeanaQF(filters);
    const euParams = { query: queryString, qf: qfParams };

    // Kleio krijgt een iets “dommere” query
    const kleioQuery = [manualQuery, ...baseKeywords].filter(Boolean).join(" ");

    // --- DE FIX ---
    // We controleren NIET meer of kleioQuery leeg is.
    // Als 'useKleio' aanstaat, roepen we hem aan.
    const searchEuropeanaFlag = useEuropeana;
    const searchKleioFlag = useKleio;
    const searchCitoFlag = useCito;
    // --- EINDE FIX ---

    // 4. Services parallel aanroepen
    console.log("[/api/search] Start parallelle zoekopdracht...");
    let europeanaPromise = Promise.resolve(null);
    let kleioPromise = Promise.resolve([]);
    let citoPromise = Promise.resolve([]);

    if (searchEuropeanaFlag) {
      console.log("[/api/search] -> Europeana params:", euParams);
      europeanaPromise = searchEuropeana(euParams);
    } else {
      console.log("[/api/search] -> Europeana overgeslagen");
    }

    if (searchKleioFlag) {
      console.log("[/api/search] -> Kleio params:", { query: kleioQuery, filters });
      kleioPromise = scrapeKleio(kleioQuery, filters, 5);
    } else {
      console.log("[/api/search] -> Kleio overgeslagen");
    }

    if (searchCitoFlag) {
      console.log("[/api/search] -> Cito params:", { tv: filters.tv || [], ka: filters.ka || [], query: manualQuery });
      citoPromise = searchCito({
        tv: filters.tv || [],
        ka: filters.ka || [],
        query: manualQuery,
      });
    } else {
      console.log("[/api/search] -> Cito overgeslagen");
    }

    const [euResult, kleioResult, citoResult] = await Promise.allSettled([
      europeanaPromise,
      kleioPromise,
      citoPromise,
    ]);

    // ... (Rest van de code: resultaten verwerken en terugsturen) ...
    let finalItems = [];
    let totalEuResults = 0;
    let kleioCount = 0;
    let citoCount = 0;
    if (euResult.status === "fulfilled" && euResult.value) {
      const { totalResults, items } = transformEuropeanaResponse(euResult.value);
      totalEuResults = totalResults;
      finalItems = finalItems.concat(items);
      console.log(`[/api/search] Europeana succes: ${totalResults} hits.`);
    } else if (euResult.status === "rejected") {
      console.error("[/api/search] Europeana FOUT:", euResult.reason?.message);
    }
    if (kleioResult.status === "fulfilled") {
      const items = transformKleioResponse(kleioResult.value);
      kleioCount = items.length;
      finalItems = finalItems.concat(items);
      console.log(`[/api/search] Kleio succes: ${kleioCount} hits.`);
    } else if (kleioResult.status === "rejected") {
      console.error("[/api/search] Kleio FOUT:", kleioResult.reason?.message);
    }
    if (citoResult.status === "fulfilled") {
      const items = transformCitoResponse(citoResult.value);
      citoCount = items.length;
      finalItems = finalItems.concat(items);
      console.log(`[/api/search] Cito succes: ${citoCount} hits.`);
    } else if (citoResult.status === "rejected") {
      console.error("[/api/search] Cito FOUT:", citoResult.reason?.message);
    }
    res.json({ totalResults: totalEuResults + kleioCount + citoCount, items: finalItems });

  } catch (err) {
    console.error("[API Fout /api/search]:", err.message);
    res.status(500).json({
      error: `Fout in /api/search: ${err.message || "Onbekende fout"}`,
      items: [],
      totalResults: 0,
    });
  }
});

module.exports = router;
