// services/data/kaMap.cjs
// Dit is de CJS (backend) versie van de data

const TIJDVAKKEN_MAP = {
  TV1: {
    id: "TV1",
    label: "1. Jagers en Boeren (tot 3000 v.C.)",
    kenmerkendeAspecten: [
      { id: 1, label: "1. Levenswijze jagers-verzamelaars" },
      { id: 2, label: "2. Ontstaan landbouw" },
      { id: 3, label: "3. Ontstaan steden" },
    ],
  },
  TV2: {
    id: "TV2",
    label: "2. Grieken en Romeinen (3000 v.C. - 500 n.C.)",
    kenmerkendeAspecten: [
      { id: 4, label: "4. Wetenschappelijk denken/filosofie" },
      { id: 5, label: "5. Grieks-Romeinse cultuur" },
      { id: 6, label: "6. Groei Romeinse Rijk (Imperium)" },
      { id: 7, label: "7. Confrontatie/romanisering" },
      { id: 8, label: "8. Jodendom en christendom" },
    ],
  },
  TV3: {
    id: "TV3",
    label: "3. Monniken en Ridders (500 - 1000)",
    kenmerkendeAspecten: [
      { id: 9, label: "9. Verspreiding christendom" },
      { id: 10, label: "10. Ontstaan/verspreiding islam" },
      { id: 11, label: "11. Hofstelsel en horigheid" },
      { id: 12, label: "12. Feodale stelsel" },
    ],
  },
  TV4: {
    id: "TV4",
    label: "4. Steden en Staten (1000 - 1500)",
    kenmerkendeAspecten: [
      { id: 13, label: "13. Opkomst handel/ambacht/steden" },
      { id: 14, label: "14. Stedelijke burgerij" },
      { id: 15, label: "15. Strijd kerk en staat" },
      { id: 16, label: "16. Kruistochten" },
      { id: 17, label: "17. Staatsvorming en centralisatie" },
    ],
  },
  TV5: {
    id: "TV5",
    label: "5. Ontdekkers en Hervormers (1500 - 1600)",
    kenmerkendeAspecten: [
      { id: 18, label: "18. Begin Europese overzeese expansie" },
      { id: 19, label: "19. Renaissance" },
      { id: 20, label: "20. Hernieuwde oriëntatie klassieke oudheid" },
      { id: 21, label: "21. Reformatie (Luther, Calvijn)" },
      { id: 22, label: "22. De Nederlandse Opstand" },
    ],
  },
  TV6: {
    id: "TV6",
    label: "6. Regenten en Vorsten (1600 - 1700)",
    kenmerkendeAspecten: [
      { id: 23, label: "23. Absolutisme (Staat van Lodewijk XIV)" },
      { id: 24, label: "24. Gouden Eeuw (Staat van de Republiek)" },
      { id: 25, label: "25. Handelskapitalisme en wereldeconomie" },
      { id: 26, label: "26. Wetenschappelijke Revolutie" },
    ],
  },
  TV7: {
    id: "TV7",
    label: "7. Pruiken en Revoluties (1700 - 1800)",
    kenmerkendeAspecten: [
      { id: 27, label: "27. De Verlichting" },
      { id: 28, label: "28. Verlicht absolutisme" },
      { id: 29, label: "29. Slavernij en abolitionisme" },
      { id: 30, label: "30. Democratische revoluties" },
    ],
  },
  TV8: {
    id: "TV8",
    label: "8. Burgers en Stoommachines (1800 - 1900)",
    kenmerkendeAspecten: [
      { id: 31, label: "31. Industriële Revolutie" },
      { id: 32, label: "32. Sociale kwestie" },
      { id: 33, label: "33. Modern imperialisme" },
      { id: 34, label: "34. Emancipatiebewegingen" },
      { id: 35, label: "35. Democratisering" },
      { id: 36, label: "36. Politiek-maatschappelijke stromingen" },
    ],
  },
  TV9: {
    id: "TV9",
    label: "9. Wereldoorlogen (1900 - 1950)",
    kenmerkendeAspecten: [
      { id: 37, label: "37. Rol van propaganda/communicatiemiddelen" },
      { id: 38, label: "38. Communisme en fascisme/nationaalsocialisme" },
      { id: 39, label: "39. De economische wereldcrisis (1929)" },
      { id: 40, label: "40. Het voeren van twee wereldoorlogen" },
      { id: 41, label: "41. Verwoesting/betrokkenheid burgerbevolking" },
      { id: 42, label: "42. De Holocaust (genocide)" },
      { id: 43, label: "43. De Duitse bezetting van Nederland" },
      { id: 44, label: "44. Vormen van verzet tegen imperialisme" },
    ],
  },
  TV10: {
    id: "TV10",
    label: "10. Televisie en Computer (1950 - heden)",
    kenmerkendeAspecten: [
      { id: 45, label: "45. Koude Oorlog (blokvorming)" },
      { id: 46, label: "46. Dekolonisatie" },
      { id: 47, label: "47. Europese eenwording" },
      { id: 48, label: "48. Jaren 60/70 (sociaal-cultureel)" },
      { id: 49, label: "49. Multiculturele samenleving" },
    ],
  },
};

module.exports = {
  tijdvakken: TIJDVAKKEN_MAP,
};
