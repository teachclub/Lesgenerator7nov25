// backend/services/a28.cito.cjs
// DEFINITIEVE VERSIE - Gebruikt alleen de 6 bekende kolommen

const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
// We hebben de kaMap niet meer nodig in deze simpele versie
// const kaMap = require("./data/kaMap.cjs"); 

let citoBronnen = [];

// Definieer hier de ECHTE kolomnamen die we nu 100% zeker weten
const COL_NIVEAU = "NIVEAU";
const COL_TV = "METADATA_TV_HC";
const COL_KA = "METADATA_KA";
const COL_INLEIDING = "INLEIDING_BRON1";
const COL_BRONTEKST = "TEKSTBRON_OFURL";
const COL_TOELICHTING = "TOELICHTING_BRON";

try {
  const csvFilePath = path.resolve(__dirname, '../data/cito_bronnen.csv');
  const fileContent = fs.readFileSync(csvFilePath, 'utf-8');
  citoBronnen = parse(fileContent, {
    columns: true,
    skip_empty_lines: true,
    delimiter: ',', 
    trim: true,
    quote: '"',
    escape: '"',
    relax_column_count: true, // Belangrijk voor de stabiliteit
  });
  console.log(`[a28.cito] Cito CSV succesvol geladen. ${citoBronnen.length} individuele bronnen beschikbaar.`);

} catch (error) {
  console.error('[a28.cito] Fout bij laden Cito CSV:', error.message);
}

// De simpele zoekfunctie die nu de JUISTE kolommen doorzoekt
const searchCito = (params) => {
  const { query, tv, ka } = params; 
  // We negeren tv en ka voor nu om de zoekopdracht te laten slagen
  const lowerCaseQuery = (query || '').toLowerCase().trim();

  if (!lowerCaseQuery) {
    const allItems = citoBronnen.map(mapRowToHit);
    return { totalResults: allItems.length, items: allItems.slice(0, 50) };
  }

  const filteredItems = citoBronnen.filter(row => {
    // We doorzoeken alleen de kolommen waarvan je 100% zeker weet
    // dat "Luther" erin staat.
    const inleiding = (row[COL_INLEIDING] || '').toLowerCase();
    const brontekst = (row[COL_BRONTEKST] || '').toLowerCase();
    const toelichting = (row[COL_TOELICHTING] || '').toLowerCase(); 

    return inleiding.includes(lowerCaseQuery) ||
           brontekst.includes(lowerCaseQuery) ||
           toelichting.includes(lowerCaseQuery);
  });

  const items = filteredItems.map(mapRowToHit);

  return {
    totalResults: items.length,
    items: items.slice(0, 50),
  };
};

// Helper om de CSV-rij om te zetten naar een 'Hit' object
const mapRowToHit = (row) => {
  const inleiding = row[COL_INLEIDING] || "Geen inleiding.";
  const bronTekst = row[COL_BRONTEKST] || "";
  const toelichting = row[COL_TOELICHTING] || "";

  // Volledige tekst (voor rechterkolom) is bron + toelichting
  const volledigeTekst = `${bronTekst} \n ${toelichting}`.trim();

  // Genereer een titel (eerste 10 woorden van inleiding)
  const titel = inleiding.split(' ').slice(0, 10).join(' ') + '...';

  return {
    id: `cito-${Math.random()}`, // We hebben geen ID-kolom
    provider: 'Cito',
    title: titel,
    description: inleiding, // Voor kolom 2 (midden)
    url: (bronTekst.startsWith("http")) ? bronTekst : null,
    thumbnail: null,
    score: 1.0, 
    highlight: volledigeTekst, // Voor kolom 3 (rechts)
  };
};

module.exports = {
  searchCito,
};
