// services/a26.scraper.cjs
// Veilige, simpele scraper voor Kleio-achtige pagina's

/**
 * Haalt de HTML van een URL op en zet die om naar platte tekst.
 * Gooit een Error als er iets misgaat.
 */
async function scrapeKleio(url) {
  if (!url || typeof url !== 'string') {
    throw new Error('Ongeldige URL voor scraper');
  }

  // Kleine sanity check om rare dingen te voorkomen
  if (!/^https?:\/\//i.test(url)) {
    throw new Error(`URL moet met http(s) beginnen: ${url}`);
  }

  console.log('[/scraper] Fetching URL:', url);

  const res = await fetch(url, { redirect: 'follow' });

  if (!res.ok) {
    throw new Error(`HTTP-fout bij scrapen: ${res.status} ${res.statusText}`);
  }

  const html = await res.text();

  // Super simpele "strip HTML" – geen cheerio nodig
  const withoutScripts = html
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '');

  const text = withoutScripts
    .replace(/<[^>]+>/g, ' ') // alle tags weg
    .replace(/\s+/g, ' ') // whitespace normaliseren
    .trim();

  // Beetje begrenzen voor veiligheid
  const maxLength = 20000;
  const sliced = text.length > maxLength ? text.slice(0, maxLength) : text;

  console.log(
    `[/scraper] Tekstlengte voor ${url}:`,
    sliced.length,
    'characters'
  );

  return sliced;
}

module.exports = {
  scrapeKleio,
};
