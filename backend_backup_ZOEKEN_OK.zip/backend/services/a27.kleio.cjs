// services/a27.kleio.cjs
// ECHTE, MAAR LICHTE KLEIO-ZOEKER (fetch + cheerio)

const cheerio = require('cheerio');

const KLEIO_SEARCH_URL = 'https://www.vgnkleio.nl/bronnen/';
const EMPTY_RESULT = { totalResults: 0, items: [] };

/**
 * params: { query: string, filters: { types?: string[] }, doelgroep?: string }
 */
async function searchKleio(params = {}) {
  const { query, filters } = params || {};
  const qs = new URLSearchParams();

  if (query && typeof query === 'string' && query.trim() !== '') {
    qs.append('_zoeken', query.trim());
  }

  // We beperken ons nu tot tekst-bronnen
  if (
    filters &&
    Array.isArray(filters.types) &&
    filters.types.includes('TEXT')
  ) {
    qs.append('_filter_bron_type', 'tekst');
  }

  const fullUrl = `${KLEIO_SEARCH_URL}?${qs.toString()}`;
  console.log('[a27.kleio] Fetch URL:', fullUrl);

  try {
    // Node 22 heeft global fetch
    const res = await fetch(fullUrl, { redirect: 'follow' });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status} ${res.statusText}`);
    }

    const html = await res.text();
    const $ = cheerio.load(html);
    const items = [];

    // De resultaten staan als headings/links onder # Bronnen,
    // in de vorm "### [Titel]" met links naar /bronnen/...
    // We pakken daarom alle <a>-tags met een /bronnen/-link
    $('a[href*="/bronnen/"]').each((index, el) => {
      const $el = $(el);
      const href = $el.attr('href') || '';
      const title = $el.text().trim();

      if (!href || !title) return;

      // Sla de generieke "Bronnen"-menu-link over
      if (href === '/bronnen/' || href.endsWith('/bronnen/')) return;

      // Maak absolute URL
      const guid = new URL(href, KLEIO_SEARCH_URL).href;

      // Probeer dichtstbijzijnde context te pakken (beschrijving)
      const container =
        $el.closest('article').length > 0
          ? $el.closest('article')
          : $el.parent(); // fallback

      const description =
        container.find('p').first().text().trim() ||
        container.text().trim().slice(0, 300);

      // Gebruik laatste padsegment als id
      const slug = guid.split('/').filter(Boolean).pop() || `kleio-${index}`;

      items.push({
        id: slug,
        guid,
        provider: 'Kleio',
        title,
        description,
        url: guid,
        thumbnail: null,
        score: 1.0,
        highlight: description,
      });
    });

    console.log(
      `[a27.kleio] Kleio-scrape voltooid. ${items.length} bronnen opgehaald.`
    );

    return {
      totalResults: items.length,
      items: items.slice(0, 50),
    };
  } catch (err) {
    console.error('[a27.kleio] Fout bij Kleio-scrape:', err.message || err);
    return EMPTY_RESULT;
  }
}

// Exporteer als named export,
// dit matcht de "slimme" import in a12.search.cjs
module.exports = {
  searchKleio,
};
