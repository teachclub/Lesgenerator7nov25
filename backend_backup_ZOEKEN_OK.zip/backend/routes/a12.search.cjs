// routes/a12.search.cjs
const express = require('express');
const router = express.Router();
const { searchEuropeana } = require('../services/a11.europeana.cjs');
const kleioModule = require('../services/a27.kleio.cjs');
const { searchCito } = require('../services/a28.cito.cjs');

// Slimme detectie: hoe exporteert a27.kleio.cjs zijn functie?
let searchKleio = null;
if (kleioModule) {
  if (typeof kleioModule.searchKleio === 'function') {
    searchKleio = kleioModule.searchKleio;
    console.log('[/api/search] Kleio-service gevonden als named export searchKleio().');
  } else if (typeof kleioModule === 'function') {
    searchKleio = kleioModule;
    console.log('[/api/search] Kleio-service gevonden als default export (functie).');
  } else {
    console.warn('[/api/search] WAARSCHUWING: a27.kleio.cjs exporteert geen functie searchKleio.');
  }
} else {
  console.warn('[/api/search] WAARSCHUWING: kleioModule is undefined/null.');
}

router.post('/search', async (req, res) => {
  const payload = req.body || {};

  console.log('[/api/search] Ontvangt payload:', JSON.stringify(payload, null, 2));

  const queryArray = Array.isArray(payload.query)
    ? payload.query.filter((t) => typeof t === 'string' && t.trim() !== '')
    : [];
  const queryTerm = queryArray.join(' ');

  const filters = payload.filters || {};
  const doelgroep = payload.doelgroep || 'onbekend';

  const providers =
    Array.isArray(filters.providers) && filters.providers.length
      ? filters.providers
      : ['Europeana', 'Kleio', 'Cito'];

  const typesFilter =
    Array.isArray(filters.types) && filters.types.length
      ? filters.types
      : ['TEXT'];

  const searchEuropeanaFlag = providers.includes('Europeana');
  const searchKleioFlag = providers.includes('Kleio');
  const searchCitoFlag = providers.includes('Cito');

  try {
    console.log('[/api/search] Start parallelle zoekopdracht...');

    const EMPTY_RESULT = { totalResults: 0, items: [] };

    const europeanaParams = {
      query: queryTerm || '*',
      qf: typesFilter.map((t) => `TYPE:"${t}"`),
    };

    const kleioParams = {
      query: queryTerm,
      filters: { types: typesFilter },
      doelgroep,
    };

    const citoParams = {
      tv: filters.tv || [],
      ka: filters.ka || [],
      query: queryTerm,
      doelgroep,
    };

    const promises = [];

    // Europeana
    if (searchEuropeanaFlag) {
      console.log('[/api/search] -> Europeana params:', europeanaParams);
      promises.push(searchEuropeana(europeanaParams));
    } else {
      promises.push(Promise.resolve(EMPTY_RESULT));
    }

    // Kleio – nu weer actief, maar met guards
    if (searchKleioFlag && searchKleio) {
      console.log('[/api/search] -> Kleio params:', kleioParams);
      try {
        const p = searchKleio(kleioParams);
        // vang async-fouten in de promise zelf
        promises.push(
          Promise.resolve(p).catch((err) => {
            console.error('[/api/search] Kleio async FOUT:', err);
            throw err;
          })
        );
      } catch (err) {
        console.error('[/api/search] Kleio SYNCHRONISCHE FOUT:', err);
        promises.push(Promise.resolve(EMPTY_RESULT));
      }
    } else {
      if (searchKleioFlag && !searchKleio) {
        console.warn(
          '[/api/search] Kleio aangevinkt, maar geen geldige searchKleio-functie gevonden; leeg resultaat.'
        );
      }
      promises.push(Promise.resolve(EMPTY_RESULT));
    }

    // Cito
    if (searchCitoFlag) {
      console.log('[/api/search] -> Cito params:', citoParams);
      promises.push(searchCito(citoParams));
    } else {
      promises.push(Promise.resolve(EMPTY_RESULT));
    }

    // Robuust: nooit meer alles onderuit door één error
    const results = await Promise.allSettled(promises);

    let allItems = [];
    let totalResults = 0;

    // 0: Europeana
    if (results[0].status === 'fulfilled') {
      const value = results[0].value || EMPTY_RESULT;
      console.log(`[/api/search] Europeana succes: ${value.totalResults} hits.`);
      allItems = allItems.concat(value.items || []);
      totalResults += value.totalResults || 0;
    } else {
      console.error(
        '[/api/search] Europeana FOUT:',
        results[0].reason?.message || results[0].reason || 'Onbekende fout'
      );
    }

    // 1: Kleio
    if (results[1].status === 'fulfilled') {
      const value = results[1].value || EMPTY_RESULT;
      console.log(`[/api/search] Kleio succes: ${value.totalResults} hits.`);
      allItems = allItems.concat(value.items || []);
      totalResults += value.totalResults || 0;
    } else {
      console.error(
        '[/api/search] Kleio FOUT:',
        results[1].reason?.message || results[1].reason || 'Onbekende fout'
      );
    }

    // 2: Cito
    if (results[2].status === 'fulfilled') {
      const value = results[2].value || EMPTY_RESULT;
      console.log(`[/api/search] Cito succes: ${value.totalResults} hits.`);
      allItems = allItems.concat(value.items || []);
      totalResults += value.totalResults || 0;
    } else {
      console.error(
        '[/api/search] Cito FOUT:',
        results[2].reason?.message || results[2].reason || 'Onbekende fout'
      );
    }

    res.json({
      totalResults,
      items: allItems.slice(0, 50),
    });
  } catch (err) {
    console.error('[/api/search] Onverwachte fout (outer catch):', err);
    res.status(500).json({ error: 'Interne serverfout in /api/search' });
  }
});

module.exports = router;
