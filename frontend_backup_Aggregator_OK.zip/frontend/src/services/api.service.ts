const API_BASE_URL = 'http://localhost:8080/api';

/**
 * 1. Haalt de hoofdzoekresultaten op.
 */
export const fetchSearchResults = async (payload: any) => {
  const response = await fetch(`${API_BASE_URL}/search`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
  }
  return response.json();
};

/**
 * 2. (NIEUW - Voor Kleio) Roept de backend-scraper (a26) aan.
 */
export const scrapeHitUrl = async (url: string): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/scrape`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.message || `Scrape-fout! Status: ${response.status}`);
  }
  const result = await response.json();
  return result.fullText;
};

/**
 * 3. (NIEUW - Voor Europeana) Roept de Europeana Record API (a24) aan.
 */
export const fetchEuropeanaRecord = async (recordId: string): Promise<any> => {
  // De ID (bv. /90402/SK_A_3262) moet URL-veilig zijn.
  const encodedId = encodeURIComponent(recordId);

  const response = await fetch(`${API_BASE_URL}/europeana/item/${encodedId}`, {
    method: 'GET',
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.message || `Europeana Record API Fout! Status: ${response.status}`);
  }
  return response.json(); 
};
