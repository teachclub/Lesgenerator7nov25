export interface Hit {
  id: string;
  provider: string;
  title: string;
  description: string;
  url: string;
  thumbnail?: string;
  score: number;
  highlight?: string;

  // **** NIEUW VELD ****
  fullText?: string; // Hier komt de gescrapete tekst of API-data
}

export interface SearchResult {
  totalResults: number;
  items: Hit[];
}
