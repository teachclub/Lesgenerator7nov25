import { Hit } from './search-result.interface';

export interface FiltersState {
  types: string[];
  providers: string[];
  periods: string[];
  noCartoons: boolean;
  tv: string[];
  ka: number[];
}

export interface QueryState {
  terms: string[];
  mode: 'ALL' | 'ANY';
  aiBoost: boolean;
  doelgroep: string;
  filters: FiltersState;
  hits: Hit[];
  totalHits: number;
  loading: boolean;
  error: string | null;

  // **** NIEUWE STATE TYPES ****
  selectedHit: Hit | null;
  isDetailLoading: boolean; // <-- NIEUW
  // **** EINDE NIEUW ****

  setTerms: (index: number, value: string) => void;
  setFilters: (newFilters: Partial<FiltersState>) => void;
  toggleArrayFilter: (key: 'providers' | 'tv' | 'ka', value: string | number) => void;
  executeSearch: () => Promise<void>;

  // **** AANGEPAST FUNCTIE TYPE ****
  setSelectedHit: (hit: Hit | null) => Promise<void> | void; // Is nu async
}
