import React from 'react';
// Importeer de store om de loading state te lezen
import { useQueryStore } from '../../../state/query.store';
import { useShallow } from 'zustand/react/shallow';
// Importeer het 'Hit' type
import { Hit } from '../../../types/search-result.interface';
// Importeer de spinner
import { ClipLoader } from 'react-spinners'; 

interface HitDetailProps {
  hit: Hit | null;
}

const HitDetail: React.FC<HitDetailProps> = ({ hit }) => {
  // Haal de loading state en de sluit-functie op
  const { isDetailLoading, setSelectedHit } = useQueryStore(
    useShallow((s) => ({
      isDetailLoading: s.isDetailLoading,
      setSelectedHit: s.setSelectedHit,
    }))
  );

  // 1. Placeholder als er geen hit is
  if (!hit) {
    return (
      <div className="h-full w-full flex items-center justify-center text-sm text-gray-500 p-4 text-center">
        Klik op een titel in de middelste kolom om hier de details te bekijken.
      </div>
    );
  }

  // 2. Spinner als we aan het laden (scrapen of API call) zijn
  if (isDetailLoading) {
    return (
      <div className="h-full w-full flex flex-col items-center justify-center text-sm text-gray-500 p-4 text-center">
        <ClipLoader color="#4A90E2" size={40} />
        <p className="mt-4">Brontekst ophalen...</p>
      </div>
    );
  }

  // 3. De daadwerkelijke content als het laden klaar is
  return (
    <div className="h-full w-full overflow-y-auto p-4 space-y-4">
      {/* Sluitknop */}
      <button
        onClick={() => setSelectedHit(null)}
        className="absolute top-2 right-3 text-2xl font-bold text-gray-400 hover:text-gray-600"
        aria-label="Sluit details"
      >
        &times;
      </button>

      <header>
        <p className="text-xs uppercase tracking-wide text-gray-400">
          {hit.provider || 'Onbekende provider'}
        </p>
        <h2 className="text-lg font-semibold mt-1">{hit.title || 'Zonder titel'}</h2>
      </header>

      {/* NIEUW: Toon de thumbnail als we die hebben (van Europeana) */}
      {hit.thumbnail && (
        <div className="w-full">
          <img
            src={hit.thumbnail}
            alt={hit.title || 'thumbnail'}
            className="max-h-64 w-auto rounded-md border border-gray-200"
          />
        </div>
      )}

      {/* Toon de 'fullText' (gescraped) of val terug op de highlight/description */}
      <p className="text-sm leading-relaxed whitespace-pre-line">
        {hit.fullText || hit.highlight || hit.description || 'Geen tekst beschikbaar.'}
      </p>

      {hit.url && (
        <a
          href={hit.url}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center text-sm font-medium text-blue-600 hover:underline"
        >
          Bekijk volledige bron
        </a>
      )}
    </div>
  );
};

export default HitDetail;
