const express = require('express');
const router = express.Router();
const searchService = require('../services/a12.search.cjs');

router.post('/', async (req, res) => {
  try {
    const { query, mode, filters, doelgroep } = req.body;
    
    let queryString = query;
    if (Array.isArray(query)) {
        const operator = mode === 'OR' ? ' OR ' : ' AND ';
        queryString = query.join(operator);
    }

    if (!queryString) {
        return res.status(400).json({ error: "Geen zoekterm" });
    }

    // We halen 100 hits op voor de resultatenlijst
    const results = await searchService.searchEuropeana(queryString, filters, 100);
    res.json(results);

  } catch (error) {
    console.error("API Error:", error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
