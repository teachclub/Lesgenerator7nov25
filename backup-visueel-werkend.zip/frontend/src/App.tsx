import React from "react";
import { GeneratorPage } from "./pages/GeneratorPage";
import "./index.css"; // Zorg dat dit bestand bestaat

export default function App() {
  return <GeneratorPage />;
}
