import { useMutation } from "@tanstack/react-query";
import { Doelgroep, Filters } from "./useSearchApi";

export interface ChipsPayload {
  query: string;
  filters: string[];
  doelgroep: Doelgroep;
}

export interface Chip {
  term: string;
  count: number;
  verified: boolean;
}

export interface ChipsApiResponse {
  ok: boolean;
  chips: Chip[];
  meta?: { count?: number };
  error?: string;
}

async function fetchChips(payload: ChipsPayload, timeoutMs = 30000): Promise<ChipsApiResponse> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(`/api/chips`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    const data = (await res.json()) as ChipsApiResponse;

    if (data && data.ok === false) {
      throw new Error(data.error || "API returned an error");
    }

    return data;
  } finally {
    clearTimeout(timer);
  }
}

export function useChipsApi() {
  return useMutation<ChipsApiResponse, Error, ChipsPayload>({
    mutationFn: (p) => fetchChips(p),
  });
}
