import { useState } from 'react';
import { useQueryStore } from '../state/query.store';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export const useSearchApi = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const setSearchResult = useQueryStore((state: any) => state.setSearchResult);

  const search = async (terms: string[], mode: string, filters: any, doelgroep: string) => {
    setIsLoading(true);
    setError(null);
    setSearchResult({ isLoading: true, isError: false, data: null });

    try {
      if (!terms || terms.length === 0) throw new Error("Geen zoektermen");

      const response = await fetch(`${API_URL}/search`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: terms, mode, filters, doelgroep }),
      });

      if (!response.ok) throw new Error('Server fout');

      const data = await response.json();
      
      setSearchResult({ 
        isLoading: false, 
        isError: false, 
        data: data 
      });

    } catch (err: any) {
      console.error("Search API Error:", err);
      setError(err.message);
      setSearchResult({ isLoading: false, isError: true, data: null });
    } finally {
      setIsLoading(false);
    }
  };

  return { search, isLoading, error };
};
