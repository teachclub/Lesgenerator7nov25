import { useState } from "react";
import axios from "axios";

export interface LessonRequestPayload {
  proposalId?: string;
  selectedSources?: any[];
  doelgroep?: any;
}

export interface LessonState {
  isLoading: boolean;
  error: string | null;
  lessonText: string | null;
}

export const useLessonApi = () => {
  const [state, setState] = useState<LessonState>({
    isLoading: false,
    error: null,
    lessonText: null,
  });

  const generateLesson = async (payload: LessonRequestPayload) => {
    try {
      setState((prev) => ({ ...prev, isLoading: true, error: null }));

      // LET OP: endpoint-naam kun je later nog aanpassen aan je backend.
      // Voor nu is dit genoeg om de frontend compilebaar te maken.
      const response = await axios.post("/api/generate/lesson", payload);

      const text =
        typeof response.data === "string"
          ? response.data
          : response.data?.lesson || "";

      setState({
        isLoading: false,
        error: null,
        lessonText: text,
      });
    } catch (err: any) {
      setState({
        isLoading: false,
        error:
          err?.message ||
          "Er ging iets mis bij het genereren van de definitieve les.",
        lessonText: null,
      });
    }
  };

  return {
    ...state,
    generateLesson,
  };
};

