import { useMutation } from '@tanstack/react-query';
import { SearchApiParams } from './useSearchApi';

export interface Proposal {
  id: string;
  title: string;
  description: string;
  mainQuestion: string;
}

export const useProposalsApi = () => {
  return useMutation<Proposal[], Error, SearchApiParams>({
    mutationKey: ['proposalsApi'],
    mutationFn: async () => {
      console.log('useProposalsApi (dummy) aangeroepen');
      return [];
    },
  });
};
