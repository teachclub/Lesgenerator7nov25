import React from 'react';
import { Proposal } from '../../api/useProposalsApi';

interface ProposalListProps {
  proposals: Proposal[] | null;
  isLoading: boolean;
  onSelect: (proposalId: string) => void;
}

export const ProposalList: React.FC<ProposalListProps> = ({ proposals, isLoading, onSelect }) => {
  if (isLoading) {
    return <div style={{ padding: '10px', marginTop: '20px' }}>Lesvoorstellen worden geladen...</div>;
  }

  if (!proposals || proposals.length === 0) {
    return null;
  }

  return (
    <section style={{ border: "1px solid #ddd", padding: 12, marginTop: 16 }}>
      <h2>2. Kies een Lesvoorstel</h2>
      <div style={{ display: 'flex', gap: '10px', justifyContent: 'space-between' }}>
        {proposals.map((proposal) => (
          <div 
            key={proposal.id} 
            style={{ 
              border: '1px solid #ccc', 
              padding: '10px', 
              flex: 1, 
              cursor: 'pointer',
              backgroundColor: '#f9f9f9'
            }}
            onClick={() => onSelect(proposal.id)}
            title="Klik om deze les te kiezen"
          >
            <h3 style={{ marginTop: 0 }}>{proposal.title}</h3>
            <p><strong>Hoofdvraag:</strong> {proposal.hoofdvraag}</p>
            <p><strong>Beschrijving:</strong> {proposal.description}</p>
            <p><small><strong>Lesopbrengst:</strong> {proposal.lesopbrengst}</small></p>
            <p><small><strong>Presentisme:</strong> {proposal.presentisme}</small></p>
          </div>
        ))}
      </div>
    </section>
  );
};
