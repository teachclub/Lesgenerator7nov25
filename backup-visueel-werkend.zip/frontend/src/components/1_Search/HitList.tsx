import React from 'react';
import { useQueryStore } from '../../state/query.store';

interface Hit {
  id: string;
  title: string;
  dcCreator?: string[];
  edmIsShownBy?: string[];
  type: string;
}

// LET OP: Hier staat nu 'export const' in plaats van default!
export const HitList: React.FC = () => {
  const state = useQueryStore((s: any) => s.searchResult);

  const items: Hit[] = state?.data?.items ?? [];
  const total = state?.data?.totalResults ?? 0;
  const isLoading = !!state?.isLoading;
  const isError = !!state?.isError;

  if (!state && !isLoading) return null;

  return (
    <div className="h-full flex flex-col">
      <h3 className="font-bold text-gray-700 mb-2 flex items-center gap-2">
        <span>📚 Treffers</span>
        {total > 0 && <span className="text-xs bg-gray-200 px-2 py-0.5 rounded-full">{total}</span>}
      </h3>

      <div className="flex-1 overflow-y-auto border border-gray-200 rounded bg-white p-2 shadow-inner custom-scrollbar" style={{maxHeight: '600px'}}>
        {isLoading && <div className="p-4 text-center text-gray-500 italic">Zoeken...</div>}
        {isError && <div className="p-4 text-center text-red-500">Fout bij laden.</div>}
        
        {!isLoading && !isError && items.length === 0 && state?.data && (
           <div className="p-4 text-center text-gray-400">Geen resultaten.</div>
        )}

        <div className="space-y-2">
          {items.map((hit) => (
            <div key={hit.id} className="flex gap-3 p-2 border-b border-gray-50 hover:bg-blue-50 transition-colors cursor-pointer group">
              <div className="w-12 h-12 flex-shrink-0 bg-gray-100 rounded border border-gray-200 overflow-hidden">
                 {hit.edmIsShownBy?.[0] ? (
                   <img src={hit.edmIsShownBy[0]} alt="" className="w-full h-full object-cover" />
                 ) : (
                   <div className="w-full h-full flex items-center justify-center text-[10px] text-gray-400">
                     {hit.type === 'IMAGE' ? '📷' : '📄'}
                   </div>
                 )}
              </div>
              
              <div className="min-w-0">
                <div className="text-sm font-medium text-gray-800 truncate group-hover:text-blue-700">
                  {hit.title}
                </div>
                <div className="text-xs text-gray-500 truncate">
                  {hit.dcCreator?.[0] || 'Onbekend'}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
