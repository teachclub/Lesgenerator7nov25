import React from 'react';
import { useQueryStore } from '../../state/query.store';
import { useSearchApi } from '../../api/useSearchApi';
import { useChipsApi } from '../../api/useChipsApi';

interface SearchActionsProps {
  onGenerateProposals: () => void;
}

// LET OP: 'export const'
export const SearchActions: React.FC<SearchActionsProps> = ({ onGenerateProposals }) => {
  const searchApi = useSearchApi();
  const chipsApi = useChipsApi();

  const terms = useQueryStore((s: any) => s.terms ?? []);
  const mode = useQueryStore((s: any) => s.mode ?? "AND");
  const filters = useQueryStore((s: any) => s.filters ?? {});
  const doelgroep = useQueryStore((s: any) => s.doelgroep ?? 'Bovenbouw VWO');

  const hasTerms = Array.isArray(terms) && terms.some((t: string) => t.trim() !== '');

  const handleSearchHits = () => {
    if (!hasTerms) return;
    searchApi.search(terms, mode, filters, doelgroep);
  };

  const handleGetSuggestions = () => {
    if (!hasTerms) return;
    chipsApi.fetchChips(terms, filters, doelgroep);
  };

  return (
    <div className="flex gap-3 mt-4 border-t pt-4 border-gray-200">
      <button
        onClick={handleSearchHits}
        disabled={searchApi.isLoading || !hasTerms}
        className="flex-1 bg-blue-100 text-blue-700 px-4 py-2 rounded hover:bg-blue-200 font-medium flex items-center justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {searchApi.isLoading ? 'Zoeken...' : '🔍 Zoek Bronnen (Hits)'}
      </button>

      <button
        onClick={handleGetSuggestions}
        disabled={chipsApi.loading || !hasTerms}
        className="flex-1 bg-yellow-100 text-yellow-800 px-4 py-2 rounded hover:bg-yellow-200 font-medium flex items-center justify-center gap-2 transition-colors border border-yellow-300 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {chipsApi.loading ? 'Denken...' : '💡 Geef Zoeksuggesties'}
      </button>

      <button
        onClick={onGenerateProposals}
        disabled={!hasTerms}
        className="flex-1 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 font-medium shadow-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed"
      >
        🚀 Genereer Lesvoorstellen
      </button>
    </div>
  );
};
