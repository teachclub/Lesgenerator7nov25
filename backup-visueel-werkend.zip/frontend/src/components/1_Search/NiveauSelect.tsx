import React from 'react';
import { useQueryStore } from '../../state/query.store';

export const NiveauSelect: React.FC = () => {
  const doelgroep = useQueryStore((s: any) => s.doelgroep ?? 'Bovenbouw VWO');
  const setDoelgroep = useQueryStore((s: any) => s.setDoelgroep);

  const options = [
    "Onderbouw VMBO", "Bovenbouw VMBO",
    "Onderbouw HAVO", "Bovenbouw HAVO",
    "Onderbouw VWO", "Bovenbouw VWO"
  ];

  return (
    <div className="mb-2">
      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">
        Doelgroep & Niveau
      </label>
      <select 
        value={doelgroep}
        onChange={(e) => setDoelgroep(e.target.value)}
        className="w-full p-2 border rounded bg-white focus:ring-2 focus:ring-blue-500"
      >
        {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
      </select>
    </div>
  );
};
