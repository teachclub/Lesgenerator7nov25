import React from 'react';
import { useQueryStore } from '../../state/query.store';

export const Filters: React.FC = () => {
  const filters = useQueryStore((s: any) => s.filters ?? {});
  const setFilters = useQueryStore((s: any) => s.setFilters);

  const handleToggle = (key: string) => {
    setFilters({ ...filters, [key]: !filters[key] });
  };

  return (
    <div className="p-3 bg-gray-50 rounded border border-gray-200 text-sm">
      <h3 className="font-bold text-gray-700 mb-2">Filters</h3>
      <div className="space-y-2">
        <label className="flex items-center gap-2 cursor-pointer">
          <input 
            type="checkbox" 
            checked={filters.onlyImages ?? false} 
            onChange={() => handleToggle('onlyImages')}
            className="rounded text-blue-600 focus:ring-blue-500"
          />
          <span>Alleen met afbeelding</span>
        </label>
        
        <label className="flex items-center gap-2 cursor-pointer">
          <input 
            type="checkbox" 
            checked={filters.noCartoons ?? false} 
            onChange={() => handleToggle('noCartoons')}
            className="rounded text-blue-600 focus:ring-blue-500"
          />
          <span>Geen spotprenten</span>
        </label>
      </div>
    </div>
  );
};
