import React from 'react';

export const TvKaSelect: React.FC = () => {
  return (
    <div className="grid grid-cols-2 gap-2">
      <div>
        <label className="block text-xs text-gray-500 mb-1">Tijdvak</label>
        <select className="w-full p-2 border rounded text-sm bg-gray-50 text-gray-400 cursor-not-allowed" disabled>
          <option>Alle Tijdvakken</option>
        </select>
      </div>
      <div>
        <label className="block text-xs text-gray-500 mb-1">Kenmerkend Aspect</label>
        <select className="w-full p-2 border rounded text-sm bg-gray-50 text-gray-400 cursor-not-allowed" disabled>
          <option>Alle KA's</option>
        </select>
      </div>
    </div>
  );
};
