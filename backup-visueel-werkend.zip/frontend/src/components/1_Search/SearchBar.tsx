import React, { useState } from 'react';
import { useQueryStore } from '../../state/query.store';

export const SearchBar: React.FC = () => {
  const terms = useQueryStore((s: any) => s.terms ?? []);
  const setTerms = useQueryStore((s: any) => s.setTerms);
  const mode = useQueryStore((s: any) => s.mode ?? "AND");
  const setMode = useQueryStore((s: any) => s.setMode);

  const [inputVal, setInputVal] = useState("");

  const handleAdd = () => {
    if (inputVal.trim()) {
      setTerms([...terms, inputVal.trim()]);
      setInputVal("");
    }
  };

  const handleRemove = (index: number) => {
    const newTerms = [...terms];
    newTerms.splice(index, 1);
    setTerms(newTerms);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleAdd();
  };

  return (
    <div className="space-y-2">
      <div className="flex gap-2">
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Typ zoekterm (bv. Luther)..."
          className="flex-1 p-2 border rounded focus:ring-2 focus:ring-blue-500 outline-none"
        />
        <button 
          onClick={handleAdd}
          className="bg-blue-600 text-white px-3 rounded hover:bg-blue-700"
        >
          +
        </button>
      </div>

      {/* Termen Lijst */}
      <div className="flex flex-wrap gap-2">
        {terms.map((term: string, idx: number) => (
          <div key={idx} className="bg-blue-100 text-blue-800 px-2 py-1 rounded flex items-center gap-1 text-sm">
            <span>{term}</span>
            <button onClick={() => handleRemove(idx)} className="text-blue-400 hover:text-blue-600 font-bold ml-1">×</button>
            {idx < terms.length - 1 && (
              <span className="text-xs text-gray-500 ml-2 font-mono cursor-pointer hover:underline" onClick={() => setMode(mode === "AND" ? "OR" : "AND")}>
                {mode}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
