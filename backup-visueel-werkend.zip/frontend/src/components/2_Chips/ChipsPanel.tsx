import React from 'react';
import { useQueryStore } from '../../state/query.store';
import { useChipsApi } from '../../api/useChipsApi';

// LET OP: Hier staat nu 'export const' (Dit is de fix!)
export const ChipsPanel: React.FC = () => {
  const chipsApi = useChipsApi();
  const terms = useQueryStore((s: any) => s.terms ?? []);
  const setTerms = useQueryStore((s: any) => s.setTerms);
  
  // Data ophalen
  const suggestions = chipsApi.data ?? []; 

  const handleChipClick = (chipLabel: string) => {
    if (!terms.includes(chipLabel)) {
        setTerms([...terms, chipLabel]);
    }
  };

  if (chipsApi.loading) return <div className="text-yellow-600 italic p-2">Analyseren...</div>;
  
  if (suggestions.length === 0) {
      return <div className="text-sm text-gray-400 p-2">Nog geen suggesties. Klik op 'Suggesties' om te starten.</div>;
  }

  return (
    <div className="flex flex-wrap gap-2 p-2">
      {suggestions.map((chip: any, idx: number) => (
        <button
          key={idx}
          onClick={() => handleChipClick(chip.label)}
          className="bg-yellow-100 hover:bg-yellow-200 text-yellow-800 px-3 py-1 rounded-full text-sm border border-yellow-300 transition-colors text-left"
        >
          <span className="font-bold">+ {chip.label}</span>
          {chip.count && <span className="text-xs text-yellow-600 ml-1">({chip.count})</span>}
        </button>
      ))}
    </div>
  );
};
