import { create } from "zustand";

type Mode = "AND" | "OR";

export type QueryState = {
  terms: string[];
  mode: Mode;
  filters: { noImages: boolean; noTexts: boolean; noCartoons: boolean };
  doelgroep: { bouw: string; niveau: string };
  setMode: (m: Mode) => void;
  addTerm: (t: string) => void;
  removeTerm: (idx: number) => void;
  updateTerm: (idx: number, v: string) => void;
  setFilters: (p: Partial<QueryState["filters"]>) => void;
  setDoelgroep: (type: 'bouw' | 'niveau', value: string) => void;
  clear: () => void;
  buildQuery: () => string;
};

export const useQueryStore = create<QueryState>((set, get) => ({
  terms: ["", "", ""],
  mode: "AND",
  filters: { noImages: false, noTexts: false, noCartoons: false },
  doelgroep: { bouw: "", niveau: "" },

  setMode: (m) => set({ mode: m }),

  addTerm: (t) => set((s) => ({ terms: [...s.terms, t] })),

  removeTerm: (idx) =>
    set((s) => ({ terms: s.terms.filter((_, i) => i !== idx) })),

  updateTerm: (idx, v) =>
    set((s) => {
      const terms = s.terms.slice();
      terms[idx] = v;
      return { terms };
    }),

  setFilters: (p) =>
    set((s) => ({ filters: { ...s.filters, ...p } })),

  setDoelgroep: (type, value) =>
    set((state) => ({
      doelgroep: { ...state.doelgroep, [type]: value }
    })),

  clear: () =>
    set({
      terms: ["", "", ""],
      mode: "AND",
      filters: { noImages: false, noTexts: false, noCartoons: false },
      doelgroep: { bouw: "", niveau: "" },
    }),

  buildQuery: () => {
    const s = get();
    const joiner = ` ${s.mode} `;
    const cleaned = s.terms.map((t) => t.trim()).filter(Boolean);
    return cleaned.join(joiner);
  },
}));
