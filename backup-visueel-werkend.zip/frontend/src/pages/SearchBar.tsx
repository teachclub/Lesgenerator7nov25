import React from 'react';

/**
 * (FRONTWIJ.F01) SearchBar
 * 
 * Dit component toont de (uiteindelijk 3+) zoekvelden en de AND/OR toggle.
 * Voor nu is het een 'dom' component. We sluiten het later aan
 * op de useQueryStore.
 */

// Tijdelijke mock-data voor de termen
const mockTerms = ['luther', '', '']; 

export const SearchBar: React.FC = () => {
  return (
    <div className="flex flex-col gap-2">
      {/* Map over de (mock) termen om de zoekvelden te tonen */}
      {mockTerms.map((term, index) => (
        <div key={index} className="flex">
          <input
            type="text"
            value={term}
            placeholder={index === 0? 'Hoofd-zoekterm...' : 'Voeg term toe...'}
            className="flex-grow p-2 border border-gray-300 rounded-l-md text-sm"
            readOnly // Tijdelijk, totdat de store is aangesloten
          />
          <button
            type="button"
            className="px-3 bg-gray-100 border-t border-b border-r border-gray-300 text-gray-500 rounded-r-md"
            title="Verwijder term"
          >
            &times;
          </button>
        </div>
      ))}

      {/* AND/OR Toggle */}
      <div className="flex items-center gap-2 mt-2">
        <button
          type="button"
          className="px-3 py-1 text-sm rounded-md bg-blue-600 text-white"
        >
          EN
        </button>
        <button
          type="button"
          className="px-3 py-1 text-sm rounded-md bg-gray-100 text-gray-700"
        >
          OF
        </button>
        <span className="text-xs text-gray-500">
          (Mode: AND)
        </span>
      </div>
    </div>
  );
};

export default SearchBar;
