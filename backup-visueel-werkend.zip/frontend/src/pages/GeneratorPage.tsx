import React from 'react';

// Onze consistente Named Imports
import { SearchBar } from '../components/1_Search/SearchBar';
import { TvKaSelect } from '../components/1_Search/TvKaSelect';
import { Filters } from '../components/1_Search/Filters';
import { NiveauSelect } from '../components/1_Search/NiveauSelect';
import { SearchActions } from '../components/1_Search/SearchActions';
import { HitList } from '../components/1_Search/HitList';
import { ChipsPanel } from '../components/2_Chips/ChipsPanel';

// DE FIX: 'export const' (Named Export) zodat App.tsx hem kan vinden
export const GeneratorPage: React.FC = () => {
  
  const handleGenerateProposals = () => {
    console.log("🚀 TODO: Navigeer naar stap 2 (Lesvoorstellen)");
  };

  return (
    <div className="container mx-auto p-4 max-w-7xl">
      {/* Header */}
      <header className="mb-6 border-b pb-4">
        <h1 className="text-3xl font-bold text-gray-800">
          Lessy <span className="text-blue-600">Lesgenerator</span>
        </h1>
        <p className="text-gray-500">Stel je ideale geschiedenisles samen in 7 stappen.</p>
      </header>

      {/* DE 3-KOLOMS LAYOUT */}
      <div className="grid grid-cols-12 gap-6 h-[calc(100vh-180px)]">
        
        {/* KOLOM 1: Zoeken & Filteren (Breedte: 4/12) */}
        <div className="col-span-4 flex flex-col bg-white p-4 rounded shadow-sm border border-gray-200 overflow-y-auto">
          <h2 className="text-lg font-bold text-gray-700 mb-4 border-b pb-2">1. Zoeken & Filteren</h2>
          
          <div className="space-y-6">
             <NiveauSelect />
             <SearchBar />
             <TvKaSelect />
             <Filters />
          </div>

          {/* De Actieknoppen */}
          <div className="mt-auto pt-4">
            <SearchActions onGenerateProposals={handleGenerateProposals} />
          </div>
        </div>

        {/* KOLOM 2: Bronnen / Hits (Breedte: 4/12) */}
        <div className="col-span-4 bg-white p-4 rounded shadow-sm border border-gray-200 flex flex-col overflow-hidden">
           <HitList />
        </div>

        {/* KOLOM 3: Suggesties / Chips (Breedte: 4/12) */}
        <div className="col-span-4 bg-yellow-50 p-4 rounded shadow-sm border border-yellow-200 flex flex-col overflow-hidden">
           <h2 className="text-lg font-bold text-yellow-800 mb-4 flex items-center gap-2">
             💡 Slimme Suggesties
           </h2>
           <div className="flex-1 overflow-y-auto">
             <ChipsPanel />
           </div>
        </div>

      </div>
    </div>
  );
};

// GEEN export default meer!
