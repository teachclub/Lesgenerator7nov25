// routes/a12.search.cjs
// Centrale zoekroute voor "2. Treffers" in de Lessy Lesgenerator.
// Ontvangt het zoekformulier van de frontend, roept de Europeana-service aan
// en geeft een nette, veilige JSON-response terug.

const { Router } = require('express');
const { performEuropeanaSearch } = require('../services/a23.europeana.cjs');

const router = Router();

/**
 * Verwachte body (useSearchApi.ts):
 * {
 *   terms: string[],
 *   mode: 'AND' | 'OR',
 *   filters: { ... },
 *   doelgroep: { niveau: string, leerweg: string },
 *   tv?: string[],
 *   ka?: string[],
 *   rows?: number,
 *   page?: number
 * }
 */
router.post('/search', async (req, res) => {
  try {
    const body = req.body || {};

    const {
      terms = [],
      mode = 'AND',
      filters = {},
      doelgroep = {},
      tv = [],
      ka = [],
      rows = 24,
      page = 1,
    } = body;

    // Safety: zorg dat terms altijd een schone array van strings is
    const safeTerms = Array.isArray(terms)
      ? terms
          .filter((t) => typeof t === 'string')
          .map((t) => t.trim())
          .filter((t) => t.length > 0)
      : [];

    const searchPayload = {
      terms: safeTerms,
      mode,
      filters,
      doelgroep,
      tv,
      ka,
      rows,
      page,
    };

    console.log('[routes/a12.search] Zoekaanvraag ontvangen:', {
      terms: safeTerms,
      mode,
      rows,
      page,
    });

    // 🔎 Roep de gedeelde Europeana-service aan
    const result = await performEuropeanaSearch(searchPayload);

    // result komt uit services/a23.europeana.cjs
    // We zijn defensief: alles netjes controleren.
    const items = Array.isArray(result?.items) ? result.items : [];
    const total =
      typeof result?.total === 'number'
        ? result.total
        : typeof result?.totalResults === 'number'
        ? result.totalResults
        : 0;

    return res.json({
      ok: true,
      items,
      totalResults: total,
      rows,
      page,
    });
  } catch (error) {
    console.error('[routes/a12.search] Fout bij zoeken:', error);

    return res.status(500).json({
      ok: false,
      message: 'Serverfout bij het ophalen van zoekresultaten.',
      error: error?.message || 'Onbekende fout',
    });
  }
});

module.exports = router;

