// services/a06.chips.cjs
// BACKWIJ.B06 — Geverifieerde Chips met 3-lagen fallback:
// 1) Gemini AI (a05.gemini.cjs)
// 2) Europeana facets (a23.facets.cjs)
// 3) Extract uit hits (performEuropeanaSearch rows=100) → tel velden (creator/subject/place/year)
// Alles daarna co-existentie-verifiëren met AND en sorteren.
const { getGeminiSuggestions } = require("./a05.gemini.cjs");
const { performEuropeanaSearch } = require("./a23.europeana.cjs");
// ⬇️ nieuwe, expliciete facets helper (moet bestaan — zie patch B)
const { getFacets } = require("./a23.facets.cjs");
const TIMEOUT_MS = 30_000;
const MAX_CONCURRENCY = 6;
const MAX_RETURN = 25;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const withTimeout = (p, ms, label="timeout") =>
  Promise.race([p, new Promise((_,rej)=>setTimeout(()=>rej(new Error(label)), ms))]);
const norm = s => String(s||"").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").trim();
const uniq = arr => {
  const seen = new Set();
  return arr.filter(x => { const k = norm(x); if (seen.has(k)) return false; seen.add(k); return true; });
};
const extractTotal = (res) => {
  if (!res) return 0;
  if (typeof res.total === "number") return res.total;
  if (res.response && typeof res.response.numFound === "number") return res.response.numFound;
  if (Array.isArray(res.docs)) return res.docs.length;
  if (Array.isArray(res.results)) return res.results.length;
  return 0;
};
const sortChips = (a,b) => {
  if (!!b.verified !== !!a.verified) return (b.verified?1:0) - (a.verified?1:0);
  if (b.count !== a.count) return b.count - a.count;
  return a.term.localeCompare(b.term, "nl");
};
const buildVerifyPayload = (baseTerms, chipTerm, base) => ({
  ...base,
  terms: [...baseTerms, chipTerm],
  mode: "AND",
  rows: 0,
  page: 1,
});

// ---- [2] Facet fallback helpers ----
function collectFacetPairs(objOrArr, group) {
  const out = [];
  if (!objOrArr) return out;

  if (Array.isArray(objOrArr)) {
    if (objOrArr.length && typeof objOrArr[0] === "object") {
      objOrArr.forEach(it => {
        const term = norm(it.term || it.label || it.name || it.value);
        const count = Number(it.count ?? it.n ?? 0) || 0;
        if (term) out.push({ term, kind: group, count });
      });
    } else {
      for (let i=0;i<objOrArr.length;i+=2) {
        const term = norm(objOrArr[i]);
        const count = Number(objOrArr[i+1] ?? 0) || 0;
        if (term) out.push({ term, kind: group, count });
      }
    }
  } else if (typeof objOrArr === "object") {
    Object.entries(objOrArr).forEach(([k,v]) => {
      const term = norm(k);
      const count = Number(v ?? 0) || 0;
      if (term) out.push({ term, kind: group, count });
    });
  }

  return out;
}
async function facetCandidates(baseTerms, base) {
  try {
    const res = await withTimeout(
      getFacets({ ...base, terms: baseTerms }),
      TIMEOUT_MS,
      "facet-timeout"
    );

    const facetsRoot =
      res?.facets ||
      res?.facet_counts ||
      res?.facetFields ||
      res?.data ||
      res ||
      {};

    const who = facetsRoot.who || facetsRoot.persons || facetsRoot.PERSON;
    const what = facetsRoot.what || facetsRoot.concepts || facetsRoot.SUBJECT;
    const where = facetsRoot.where || facetsRoot.places || facetsRoot.PLACE || facetsRoot.spatial;
    const year = facetsRoot.YEAR || facetsRoot.when || facetsRoot.DATES || facetsRoot.year;

    const out = [
      ...collectFacetPairs(who, "person"),
      ...collectFacetPairs(what, "concept"),
      ...collectFacetPairs(where, "place"),
      ...collectFacetPairs(year, "time")
    ];

    const dedup = uniq(out.map(x => x.term)).map(t => {
      const rec = out.find(x => x.term === t) || { term: t, kind: "other", count: 0 };
      return rec;
    });

    return dedup.sort((a,b)=>b.count-a.count).slice(0, 50);
  } catch (e) {
    console.warn("[a06.chips] facetCandidates fout:", e.message);
    return [];
  }
}

// ---- [3] Laatste redmiddel: extract uit hits ----
function tallyFromHits(docs) {
  const buckets = new Map(); // term -> {count, kind}
  const bump = (term, kind="other", n=1) => {
    const t = norm(term);
    if (!t) return;
    const prev = buckets.get(t) || { count: 0, kind };
    buckets.set(t, { count: prev.count + n, kind: prev.kind || kind });
  };

  (docs||[]).forEach(d => {
    const creators = [].concat(d.dcCreator, d["dc:creator"], d.creator).filter(Boolean).flat();
    const subjects = [].concat(d.dcSubject, d["dc:subject"], d.subject).filter(Boolean).flat();
    const places   = [].concat(d.dctermsSpatial, d["dcterms:spatial"], d.place, d.spatial, d.coverage).filter(Boolean).flat();
    const dates    = [].concat(d["dcterms:created"], d["dc:date"], d.date, d.year).filter(Boolean).flat();

    creators.forEach(x => bump(x, "person"));
    subjects.forEach(x => bump(x, "concept"));
    places.forEach(x => bump(x, "place"));
    dates.forEach(x => bump(String(x), "time"));
  });

  return Array.from(buckets.entries())
    .map(([term, v]) => ({ term, kind: v.kind || "other", count: v.count }))
    .sort((a,b)=>b.count-a.count)
    .slice(0, 50);
}
async function lastResortCandidates(baseTerms, base) {
  try {
    const res = await withTimeout(
      performEuropeanaSearch({ ...base, terms: baseTerms, rows: 100, page: 1 }),
      TIMEOUT_MS,
      "hits-timeout"
    );
    const docs = res?.docs || res?.results || res?.items || res?.response?.docs || [];
    return tallyFromHits(docs);
  } catch (e) {
    console.warn("[a06.chips] lastResortCandidates fout:", e.message);
    return [];
  }
}

// ---- hoofdservice ----
async function generateVerifiedChips(searchPayload = {}) {
  const { terms = [], mode = "AND", doelgroep = {}, filters = {}, tv = [], ka = [] } = searchPayload;
  const baseTerms = uniq((terms||[]).map(norm).filter(Boolean));
  const base = { doelgroep, filters, tv, ka, mode };

  // 1) Probeer AI
  let potential = [];
  try {
    const ai = await withTimeout(getGeminiSuggestions(searchPayload), TIMEOUT_MS, "chips-ai-timeout");
    potential = Array.isArray(ai) ? ai.map(c => ({
      term: norm(c.label || c.term || c.name || c.title),
      kind: String(c.type || c.kind || "other").toLowerCase(),
    })) : [];
  } catch (e) {
    console.warn("[a06.chips] AI-suggesties fout:", e.message);
  }

  // 2) Facets fallback
  if (potential.length === 0) {
    console.log("[a06.chips] AI faalde, fallback naar Europeana-facetten…");
    potential = await facetCandidates(baseTerms, base);
  }

  // 3) Laatste redmiddel: extract uit hits
  if (potential.length === 0) {
    console.log("[a06.chips] Facetten leeg, fallback naar hits-extract…");
    potential = await lastResortCandidates(baseTerms, base);
  }

  // schoon: geen duplicaten & niet gelijk aan bestaande terms
  const baseSet = new Set(baseTerms.map(norm));
  const cleaned = uniq(potential.map(p => p.term))
    .filter(t => t && t.length>=2 && !baseSet.has(t))
    .map(t => {
      const k = (potential.find(p => p.term === t)?.kind) || "other";
      return { term: t, kind: k };
    });

  if (cleaned.length === 0) return [];

  // co-existentie-verificatie
  const results = [];
  let i = 0;
  async function verifyOne(chip) {
    const res = await withTimeout(
      performEuropeanaSearch(buildVerifyPayload(baseTerms, chip.term, base)),
      TIMEOUT_MS,
      "chips-verify-timeout"
    );
    const total = extractTotal(res);
    return { term: chip.term, kind: chip.kind, count: total, verified: total > 0 };
  }
  async function worker() {
    while (i < cleaned.length) {
      const idx = i++;
      const chip = cleaned[idx];
      try {
        const v = await verifyOne(chip);
        if (v.count > 0) results.push(v);
      } catch (_) {}
      if (idx % 5 === 4) await sleep(0);
    }
  }
  const workers = Array.from({ length: Math.min(MAX_CONCURRENCY, cleaned.length) }, worker);
  await Promise.all(workers);

  results.sort(sortChips);
  return results.slice(0, MAX_RETURN);
}
module.exports = { generateVerifiedChips };
