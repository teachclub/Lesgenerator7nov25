const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require('@google/generative-ai');

// Haal de API-sleutel en modelnaam uit de omgevingsvariabelen
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL_CHIPS = process.env.GEMINI_MODEL_CHIPS;

if (!GEMINI_API_KEY || !GEMINI_MODEL_CHIPS) {
  console.error(
    '[a05.gemini] FATALE FOUT: GEMINI_API_KEY of GEMINI_MODEL_CHIPS mist.'
  );
  throw new Error('Gemini API-sleutel of modelnaam is niet ingesteld.');
}

// Initialiseer het model
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const model = genAI.getGenerativeModel({
  model: GEMINI_MODEL_CHIPS,
  // Zorg ervoor dat we geen 'unsafe' content blokkeren die relevant is (bv. oorlog)
  safetySettings: [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
    },
    {
      category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
      threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
    },
    {
      category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
      threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
    },
    {
      category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
      threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
    },
  ],
});

/**
 * @service a05.gemini.cjs
 * @desc Genereert *mogelijke* zoeksuggesties (chips) o.b.v. de huidige query.
 * @param {object} searchPayload
 * @returns {Promise<Array<{label: string, type: string}>>}
 */
const getGeminiSuggestions = async (searchPayload) => {
  const { terms = [], doelgroep = {}, tv = [], ka = [] } = searchPayload;

  const validTerms = terms.filter((t) => t && t.trim() !== '').join(' EN ');
  const context = `
    Context:
    - Doelgroep: ${doelgroep.onderbouw || ''} ${doelgroep.niveau || ''}
    - Zoektermen: ${validTerms}
    - Tijdvak: ${tv.join(', ') || 'n.v.t.'}
    - Kenmerkend Aspect: ${ka.join(', ') || 'n.v.t.'}
  `;

  const prompt = `
    Je bent een expert in de Nederlandse geschiedenis en de Europeana-dataset.
    Een docent zoekt naar bronnen met de volgende context:
    ${context}

    Geef 10-15 *gerelateerde* zoeksuggesties (co-termen) die de zoekopdracht verfijnen.
    Focus op specifieke, gerelateerde termen.
    Retourneer ALLEEN een valide JSON-array, zonder markdown.
    Formaat: [
      {"label": "Calvijn", "type": "Persoon"},
      {"label": "Hugenoten", "type": "Groep"},
      {"label": "Worms", "type": "Plaats"},
      {"label": "Reformatie", "type": "Gebeurtenis"},
      {"label": "Smeekschrift der Edelen", "type": "Document"}
    ]
  `;

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = await response.text();

    // Verwijder eventuele markdown-backticks
    const cleanedText = text.replace(/```json/g, '').replace(/```/g, '').trim();
    const suggestions = JSON.parse(cleanedText);
    
    return suggestions;
  } catch (error) {
    console.error(
      '[a05.gemini] Fout bij genereren van chips:',
      error.message
    );
    // Gooi de fout verder zodat a06 het kan afvangen
    throw new Error('Gemini API-fout bij chips genereren: ' + error.message);
  }
};

module.exports = {
  getGeminiSuggestions,
};
