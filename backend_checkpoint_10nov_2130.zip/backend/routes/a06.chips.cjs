const express = require("express");
const router = express.Router();

let suggestChipsReal = null;
try {
  const svc = require("../services/a06.chips.cjs");
  if (svc && typeof svc.suggestChips === "function") suggestChipsReal = svc.suggestChips;
} catch (_) {}

function dynFallback(query = "") {
  const q = String(query || "").toLowerCase();

  // Snelle profielen
  if (/\bluther\b/.test(q) || /\bcalvijn\b/.test(q) || /\breformatie\b/.test(q)) {
    return ["reformatie","95 stellingen","worms 1521","aflaat","wittenberg","drukpers","bron","cartoon","brief","context","analyse"];
  }
  if (/\bhitler\b/.test(q) || /\bnazi\b/.test(q) || /\bnationaalsocialisme\b/.test(q)) {
    return ["partijprogramma NSDAP","machtsgreep 1933","Rijksdagbrand","Ermächtigungsgesetz","propaganda Goebbels","SA/SS","antisemitisme","bron","cartoon","brief","context","analyse"];
  }
  if (/\brembrandt\b/.test(q)) {
    return ["ets","chiaroscuro","De Nachtwacht","portret","Jan Six","atelier","Amsterdam 17e eeuw","bron","cartoon","brief","context","analyse"];
  }

  // Generiek: split de termen en vul aan
  const tokens = q
    .split(/\s+|,|;|AND|OR/gi)
    .map(s => s.trim())
    .filter(Boolean)
    .slice(0, 6);

  const base = ["bron","cartoon","brief","context","analyse"];
  return Array.from(new Set([...tokens, ...base]));
}

router.post("/chips", async (req, res) => {
  const body = req.body || {};
  const searchTerm =
    (typeof body.query === "string" && body.query.trim()) ||
    (typeof body.term  === "string" && body.term.trim())  ||
    (typeof body.q     === "string" && body.q.trim())     || "";

  const filters = Array.isArray(body.filters) ? body.filters : [];
  const started = Date.now();
  console.log("[chips] IN", { query: searchTerm, filters });

  try {
    if (suggestChipsReal) {
      const out = await suggestChipsReal({ query: searchTerm, filters });
      const chips = Array.isArray(out?.chips) ? out.chips : [];
      if (chips.length) {
        return res.status(200).json({ ok: true, chips, meta: { real: true, tookMs: Date.now()-started, count: chips.length }});
      }
    }
    const chips = dynFallback(searchTerm);
    return res.status(200).json({ ok: true, chips, meta: { real: false, tookMs: Date.now()-started, count: chips.length }});
  } catch (err) {
    console.error("[chips] ERROR", err?.stack || err);
    const chips = dynFallback(searchTerm);
    return res.status(200).json({ ok: false, error: String(err?.message||err), chips, meta: { real: false, tookMs: Date.now()-started, count: chips.length }});
  }
});

module.exports = router;

