// routes/a25.proposals.cjs
// MOCK-implementatie voor /api/pre-selection
// Stuurt direct 3 proposals terug op basis van de query (zonder Gemini).
const express = require("express");
const router = express.Router();

function mk(id, title, summary) {
  return { id: String(id), title, summary };
}

function proposalsFor(query) {
  const q = String(query || "").toLowerCase();

  if (/\bhitler\b|\bnazi\b|\bnationaalsocialisme\b/.test(q)) {
    return [
      mk(1, "Machtsgreep en legitimatie (1933)", "Hoe wettelijke en extralegale stappen (Rijksdagbrand, Ermächtigungsgesetz) een dictatuur legitimeerden."),
      mk(2, "Propaganda en sociale mobilisatie", "De rol van Goebbels, massabijeenkomsten en radio in het vormen van ‘volksgemeenschap’."),
      mk(3, "Uitsluiting en geweld in beleid", "Van antisemitische retoriek naar systematische uitsluiting en geweld (SA/SS)."),
    ];
  }

  if (/\bluther\b|\bcalvijn\b|\breformatie\b/.test(q)) {
    return [
      mk(1, "Reformatie als mediarevolutie", "Drukpers, pamfletten en vertalingen: waarom ideeën razendsnel verspreidden."),
      mk(2, "Geweten versus gehoorzaamheid", "Debat over autoriteit van kerk en Bijbel; Worms (1521) en gewetensvrijheid."),
      mk(3, "Religie en politiek in conflict", "Vorsten, boerenoorlog en de scheidslijnen in het Heilig Roomse Rijk."),
    ];
  }

  if (/\brembrandt\b/.test(q)) {
    return [
      mk(1, "Atelierpraktijk en opdrachtgever", "Relatie met mecenas, gilde en markt; groepsportret versus individuele expressie."),
      mk(2, "Techniek en licht", "Ets, chiaroscuro en experiment als motor van stijlontwikkeling."),
      mk(3, "Stad en samenleving", "Amsterdamse context: migratie, welvaart en cultuur in de 17e eeuw."),
    ];
  }

  // generiek fallback: drie neutrale sjablonen
  return [
    mk(1, "Context – oorzaken en drijfveren", "Wat dreef actoren? Materiële/ideële motieven, korte vs. lange termijn."),
    mk(2, "Bronnen kritisch inzetten", "Soorten bronnen, betrouwbaarheid, perspectief en representativiteit."),
    mk(3, "Gevolgen en betekenis", "Directe vs. indirecte effecten; korte en lange termijn, winners/losers."),
  ];
}

router.post("/pre-selection", (req, res) => {
  const { query = "", filters = [] } = req.body || {};
  const list = proposalsFor(query);
  return res.status(200).json({
    ok: true,
    proposals: list,
    meta: { count: list.length, filters, query },
  });
});

module.exports = router;

